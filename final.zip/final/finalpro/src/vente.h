typedef struct{
char reference[70];
char categorie[70];
char type[70];
char quantite[70];
char date[70];
int jour;
int mois;
int annee;
}produit;

void afficher_m(GtkWidget *liste);
void ajouter_m(produit p);
void supprimer_m(produit p);
void afficher_recherche(GtkWidget *liste,char*ref);



