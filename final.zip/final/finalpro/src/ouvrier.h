#include <gtk/gtk.h>
#ifndef OUVRIER_H_INCLUDED
#define OUVRIER_H_INCLUDED
typedef struct
	{
	 int jour;
	 int mois;
	 int annee;
	}Date;

typedef struct
{
char ID[30];
char nom[30];
char prenom[30];
char numero[30];
char adresse[30];
Date date;
char date1[30];
char specialite[30];
char sexe[30];
}ouvrier;

void ajouter_ouvrier(ouvrier c);
void supprimer_ouvrier(ouvrier c);
void afficher_ouvriers(GtkWidget *liste);//treeview initialement meebia
void afficher_id(GtkWidget *liste,char ident[]);//recherche par tt les caract a faire//a faire rech sans afficher une autre fenetre 
int exist(char ident[]);



#endif

