int exist_annee(tabAnneeMoy*e,int n,int aa);
int remplir_annees(tabAnneeMoy*e,char*fich);
int maximum(tabAnneeMoy*e,int n);
float calculer_moy(int aa, char*fich);
int trouver_annee_plus_seche(char*fich);
