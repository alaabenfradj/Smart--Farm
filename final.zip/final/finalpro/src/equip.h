

typedef struct {
char Ref[20];
char designation[20];
char marque[20];
char etat[20];
char date_achat[100];

}equipement;


void ajouter_equipement(equipement e);
void supprimer_equipement(equipement e);
void modifier_equipement(char Ref,equipement e1);
void afficher_equipement(GtkWidget *liste);
void chercher_equipement2(char ref[]);
void afficher_equipement2(GtkWidget *liste);
void deffect();
void chercher_equipement(GtkWidget *liste);
void marquedef22();
