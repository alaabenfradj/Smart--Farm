#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ouvrier.h"

enum
{
Eid,
Ename,
Eprename,
Enumber,
Eadress,
EDATE,
ESPECIALITE,
ESEXE,
COLUMNS,
};

void ajouter_ouvrier(ouvrier c)
{

    FILE* f = NULL;
    f= fopen("fonction.txt", "a+");

if (f!=NULL)

{
    fprintf(f,"%s %s %s %s %s %s %s %s\n",c.ID,c.nom,c.prenom,c.numero,c.adresse,c.date1,c.specialite,c.sexe);
    fclose(f);
}
}

void afficher_ouvriers(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char ID[30];
char nom[30];
char prenom[30];
char numero[30];
char adresse[30];
char date[30];
char specialite[30];
char sexe[30];

store=NULL;

FILE *f= NULL;
store=gtk_tree_view_get_model(liste);

if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("ID",renderer,"text",Eid,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Ename,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Eprename,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("numero",renderer,"text",Enumber,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",Eadress,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",ESPECIALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 

f=fopen("fonction.txt","r");

if (f==NULL)
{
return;
}
else
{
f=fopen("fonction.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",ID,nom,prenom,numero,adresse,date,specialite,sexe)!=EOF)
	{

gtk_list_store_append (store,&iter);				  	gtk_list_store_set(store,&iter,Eid,ID,Ename,nom,Eprename,prenom,Enumber,numero,Eadress,adresse,EDATE,date,ESPECIALITE,specialite,ESEXE,sexe,-1);
	}

	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}


void supprimer_ouvrier(ouvrier c)

{
ouvrier c1;
    FILE* f = NULL;
     FILE* ftemp= NULL;
        f= fopen("fonction.txt", "r");
        ftemp = fopen("fonction_temp.txt", "a+");

 if (f!=NULL)

{
     while(fscanf(f,"%s %s %s %s %s %s %s %s\n",c1.ID,c1.nom,c1.prenom,c1.numero,c1.adresse,c1.date1,c1.specialite,c1.sexe)!=EOF)

    {
     if ( strcmp(c1.ID,c.ID) != 0)
    fprintf(ftemp,"%s %s %s %s %s %s %s %s\n",c1.ID,c1.nom,c1.prenom,c1.numero,c1.adresse,c1.date1,c1.specialite,c1.sexe);
    }
}
    fclose(f);
    fclose(ftemp);
    remove("fonction.txt");
    rename("fonction_temp.txt","fonction.txt");
}



void afficher_id(GtkWidget *liste,char ident[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char ID[30];
char nom[30];
char prenom[30];
char numero[30];
char adresse[30];
char date[30];
char specialite[30];
char sexe[30];

store=NULL;

FILE *f= NULL;
store=gtk_tree_view_get_model(liste);

if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("ID",renderer,"text",Eid,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Ename,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Eprename,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("numero",renderer,"text",Enumber,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",Eadress,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",ESPECIALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 

f=fopen("fonction.txt","r");

if (f==NULL)
{
return;
}
else
{
f=fopen("fonction.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",ID,nom,prenom,numero,adresse,date,specialite,sexe)!=EOF)
	{
	if (strcmp(ID,ident)==0)
	{
gtk_list_store_append (store,&iter);				  	gtk_list_store_set(store,&iter,Eid,ID,Ename,nom,Eprename,prenom,Enumber,numero,Eadress,adresse,EDATE,date,ESPECIALITE,specialite,ESEXE,sexe,-1);
	}
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}


int exist(char ident[])
{
char ID[30];
char nom[30];
char prenom[30];
char numero[30];
char adresse[30];
char date[30];
char specialite[30];
char sexe[30];
 FILE*f;
 int exist=-1;

 f=fopen("fonction.txt" , "r");
 if (f!=NULL)
	{
	 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",ID,nom,prenom,numero,adresse,date,specialite,sexe)!=EOF)
		{
		 if (strcmp(ID,ident)==0 )
			 exist=1;	
		}
	}

 fclose(f);

 return(exist);						
}

