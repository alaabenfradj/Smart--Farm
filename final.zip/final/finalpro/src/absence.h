#include <gtk/gtk.h>
#define ABSENCE_H_INCLUDED
#define ABSENCE_H_INCLUDED

typedef struct
{
char Identifiant[30];
int jours;
int moiss;
int annees;
char Date[30];
char Absence[30];
}absence;

absence a;

void ajouter_abs(absence a);
void afficher_abs(GtkWidget *liste);
void supprimer_abs(absence a);
void recherche(GtkWidget *liste,char idd[],char abs[]);
int exist_ab(char idd[]);
float taux_abs(char year[],char month[]);
