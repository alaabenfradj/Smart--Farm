#include<stdio.h>
#include<stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include "final.h"
enum
{
 EREFERENCE,
 ENOM,
 EPRENOM,
 EGENRE,
 EADRESSE,
 ETELEPHONE,
 EEMAIL,
 EDATE,
 COLUMNS
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ajouterma(client c)
{

FILE *f=NULL;
f = fopen("clients.txt", "a+" );
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s\n",c.reference,c.nom,c.prenom,c.genre,c.adresse,c.telephone,c.email,c.date);
fclose(f);
}
else
printf("impossible d'ouvrir le fichier");
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficherma(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

 char reference[70];
 char nom[70];
 char prenom[70];
 char adresse[70];
 char telephone[70];
 char email[70];
 char date[70];
 char genre[70];

 store=NULL;
 FILE *f;
 store=gtk_tree_view_get_model(liste);
if (store==NULL)
  {
  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("reference",renderer,"text",EREFERENCE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",EADRESSE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",ETELEPHONE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

 renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


 renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("clients.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("clients.txt","a+");
 while( fscanf(f,"%s %s %s %s %s %s %s %s\n",reference,nom,prenom,genre,adresse,telephone,email,date)!=EOF)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EREFERENCE,reference,ENOM,nom,EPRENOM,prenom,EGENRE,genre,EADRESSE,adresse,ETELEPHONE,telephone,EEMAIL,email,EDATE,date,-1); //mise à jour des données
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void supprimerma(client c)
{
FILE*f=NULL;
FILE*ftemp=NULL;
 client c1;
f= fopen("clients.txt", "r");

 ftemp = fopen("clients_temp.txt", "a+");
 if (f!=NULL)

{
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",c1.reference,c1.nom,c1.prenom,c1.genre,c1.adresse,c1.telephone,c1.email,c1.date)!=EOF)
{
if(strcmp(c1.reference,c.reference)!=0)
fprintf(ftemp,"%s %s %s %s %s %s %s %s\n",c1.reference,c1.nom,c1.prenom,c1.genre,c1.adresse,c1.telephone,c1.email,c1.date);
}
}
fclose(f);
fclose(ftemp);
remove("clients.txt");
    rename("clients_temp.txt","clients.txt");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void afficher_rechma(GtkWidget *liste,char*ref)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

 char reference[70];
 char nom[70];
 char prenom[70];
 char adresse[70];
 char telephone[70];
 char email[70];
 char date[70];
 char genre[70];
 store=NULL;
 FILE *f;
 store=gtk_tree_view_get_model(liste);
if (store==NULL)
  {
  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("reference",renderer,"text",EREFERENCE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",EADRESSE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",ETELEPHONE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

 renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


 renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("clients.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("clients.txt","a+");
 while( fscanf(f,"%s %s %s %s %s %s %s %s\n",reference,nom,prenom,genre,adresse,telephone,email,date)!=EOF)
	{
	if (strcmp(reference,ref)==0)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EREFERENCE,reference,ENOM,nom,EPRENOM,prenom,EGENRE,genre,EADRESSE,adresse,ETELEPHONE,telephone,EEMAIL,email,EDATE,date,-1); //mise à jour des données
	}
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	}


