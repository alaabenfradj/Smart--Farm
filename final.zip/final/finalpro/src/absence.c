#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "absence.h"

enum
{
EIDENT,
EDATES,
EABSENCE,
COLUMNS,
};


void ajouter_abs(absence a)
{
    FILE* f = NULL;
    f= fopen("abs.txt", "a+");

if (f!=NULL)

{
    fprintf(f,"%s %s %s\n",a.Identifiant,a.Date,a.Absence);
    fclose(f);
}
}

void afficher_abs(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char Identifiant[30];//
char Date[30];//
char Absence[30];//

store=NULL;

FILE *f= NULL;
store=gtk_tree_view_get_model(liste);

if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EIDENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",EDATES,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Absence",renderer,"text",EABSENCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 

f=fopen("abs.txt","r");

if (f==NULL)
{
return;
}
else
{
f=fopen("abs.txt","a+");
while(fscanf(f,"%s %s %s\n",Identifiant,Date,Absence)!=EOF)
	{

gtk_list_store_append (store,&iter);
gtk_list_store_set(store,&iter,EIDENT,Identifiant,EDATES,Date,EABSENCE,Absence,-1);
	}

	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}

void supprimer_abs(absence a)
{
absence a1;
    FILE* f = NULL;
     FILE* ftemp= NULL;
        f= fopen("abs.txt", "r");
        ftemp = fopen("abs_temp.txt", "a+");

 if (f!=NULL)

{
     while(fscanf(f,"%s %s %s\n",a1.Identifiant,a1.Date,a1.Absence)!=EOF)

    {
     if (strcmp(a1.Identifiant,a.Identifiant)!=0)
    fprintf(ftemp,"%s %s %s\n",a1.Identifiant,a1.Date,a1.Absence);
    }
}
    fclose(f);
    fclose(ftemp);
    remove("abs.txt");
    rename("abs_temp.txt","abs.txt");
}





int exist_ab(char idd[])
{
char Identifiant[30];//
char Date[30];//
char Absence[30];//

 FILE*f;
 int exist=-1;

 f=fopen("fonction.txt" , "r");
 if (f!=NULL)
	{
	 while (fscanf(f,"%s %s %s\n",Identifiant,Date,Absence)!=EOF)
		{
		 if (strcmp(Identifiant,idd)==0 )
			 exist=1;	
		}
	}

 fclose(f);

 return(exist);						
}

void recherche(GtkWidget *liste,char idd[],char abs[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
absence a;
char Identifiant[30];//
char Date[30];//
char Absence[30];//

store=NULL;

FILE *f= NULL;
store=gtk_tree_view_get_model(liste);

if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EIDENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",EDATES,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Absence",renderer,"text",EABSENCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 

f=fopen("abs.txt","r");

if (f==NULL)
{
return;
}
else
{
f=fopen("abs.txt","a+");
while(fscanf(f,"%s %s %s\n",Identifiant,Date,Absence)!=EOF)
	{
if (strcmp(Identifiant,idd)==0 || strcmp(Absence,abs)==0)
	{
gtk_list_store_append (store,&iter);				  	
gtk_list_store_set(store,&iter,EIDENT,Identifiant,EDATES,Date,EABSENCE,Absence,-1);
	}
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}


float taux_abs(char year[],char month[])
{
absence a;
FILE *f= NULL;
    int absences=0;
    f= fopen("abs.txt","r");
float t;
char n[30]="1";
    if (f!=NULL)
{
    while(fscanf(f,"%s %s %s\n",a.Identifiant,a.Date,a.Absence)!=EOF)
    {


    if(strstr(a.Date,year)!=0 && strcmp(a.Absence,n)==0 && strstr(a.Date,month)!=0 )
      {
        absences++;
      }
    }
t= (float)((absences*100)/31);

}
fclose(f);
return (t);
}
