#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
int rech(char n[20])
{int test;
  plante p;
  FILE*f;
  f=fopen("planning_plante.txt","r");
   test=0;
   if (f!=NULL)
{
 while (fscanf(f," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte)!=EOF)
{
            if (strcmp(n,p.nom)==0)
{    
                 test=1;
		break;
		return 1;
}
}
fclose(f);}
if (test==0)
{return 0;}
else
 {return 1;}
}

