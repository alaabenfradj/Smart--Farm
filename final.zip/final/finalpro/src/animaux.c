#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif 


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "animaux.h"
#include <gtk/gtk.h>

enum
{
EMATRICULE,
ESEXE,
EJOUR,
EMOIS,
EANNEE,
EESPECE,
ESANTE,
EAGE,
COLUMNS,
};
//ajouter//////////////////////////////////////////////////////////////////////////////////////////
void ajouter(troupeaux a)
{
int x,y;
FILE *f ;
f=fopen("users.txt","a+");
if(f!=NULL)
{
x=atoi(a.annee);
y=2021-x;
sprintf(a.age,"%d",y);
fprintf(f,"%s %s %s %s %s %s %s %s\n",a.matricule,a.espece,a.jour,a.mois,a.annee,a.sexe,a.sante,a.age);
fclose(f);
}
}
//afficher//////////////////////////////////////////////////////////////////////////////////////////
void  afficher_troupeaux(GtkWidget *liste)
{
 

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

    char matricule[20] ;
    char jour[20] ;
    char mois[20];
    char annee[20];
    char espece[20];
    char sexe[20];
    char sante[20];
    char age[20];
	store=NULL;
	
	FILE *f;
	
	store=gtk_tree_view_get_model(liste);
	
	if (store==NULL);
{

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("matricule",renderer,"text",EMATRICULE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("espece",renderer,"text",EESPECE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        
        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("sante",renderer,"text",ESANTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        
          renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("age",renderer,"text",EAGE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

       



}

store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("users.txt","r");
if (f==NULL)
{
return;
}
else
{
f=fopen("users.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s ",matricule,espece,jour,mois,annee,sexe,sante,age)!=EOF)
	{
		gtk_list_store_append (store,&iter);
		gtk_list_store_set(store,&iter,EMATRICULE,matricule,EESPECE,espece,EJOUR,jour,EMOIS,mois,EANNEE,annee,ESEXE,sexe,ESANTE,sante,EAGE,age,-1);
	}

	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}







//supprimer///////////////////////////////////////////////////////////////////////////////////
void supprimer(troupeaux s)
{


    FILE *f;
    FILE *fw;
    f=fopen("users.txt","r");
    fw=fopen("users2.txt","w");
    troupeaux p;

    if(f!=NULL)
    {
      while(fscanf(f,"%s %s %s %s %s %s %s %s",p.matricule,p.espece,p.jour,p.mois,p.annee,p.sexe,p.sante,p.age)!=EOF)
       {
         if (strcmp(p.matricule,s.matricule)!=0)
        fprintf(fw,"%s %s %s %s %s %s %s %s\n",p.matricule,p.espece,p.jour,p.mois,p.annee,p.sexe,p.sante,p.age);
       }
    }
    fclose(f);
    fclose(fw);
    remove("users.txt");
    rename("users2.txt","users.txt");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modifier(troupeaux m,troupeaux k)
{
    FILE *f;
    FILE *fw;
    f=fopen("users.txt","r");
    fw=fopen("users2.txt","w");
    troupeaux s;
    int x,y;

   
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %s %s %s %s",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age)!=EOF)
       {

           if(strcmp(s.matricule,k.matricule)==0)
           {
          x=atoi(m.annee);
          y=2021-x;
         sprintf(m.age,"%d",y);
       fprintf(fw,"%s %s %s %s %s %s %s %s\n",m.matricule,m.espece,m.jour,m.mois,m.annee,m.sexe,m.sante,m.age);}
       else
        
       fprintf(fw,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);

       }
    }
    fclose(f);
    fclose(fw);
    remove("users.txt");
    rename("users2.txt","users.txt");


}
//////////////////////////////////////////////////////////////////////////////////////////////////

void nb_troupeaux_type( )
{

FILE *f;
FILE *fw;
FILE *g;
g=fopen("nbrt1.txt","a+");
remove("nbrt.txt");
rename("nbrt1.txt","nbrt.txt");
fclose(g);

int v=0;
int c=0;
int p=0;
int co=0;
int l=0;
int m=0;
int d=0;
int chev=0;
int can=0;
int a=0;
float ov=0;
float oc=0;
float op=0;
float oco=0;
float ol=0;
float om=0;
float od=0;
float ochev=0;
float ocan=0;
float oa=0;

troupeaux s;

char vachech[10];
char chevalch[10];
char poulech[10];
char coqch[10];
char lapinch[10];
char moutonch[10];
char dindonch[10];
char chevrech[10];
char canardch[10];
char anech[10];
f=fopen("users.txt","r");
fw=fopen("nbrt.txt","a+");


    if((f!=NULL)&&(fw!=NULL))
    {
     while(fscanf(f,"%s %s %s %s %s %s %s %s",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age)!=EOF)
      {
          if (strcmp(s.espece,"vache")==0)
           {
             v++;
             if(strcmp(s.sante,"OK")==0)
             {ov++;}
             
           }
          
           else if (strcmp(s.espece,"cheval")==0)
            { c++; 
              if(strcmp(s.sante,"OK")==0)
             {oc++;}
            
             }
        else  if (strcmp(s.espece,"poule")==0)
             {p++;  
            if(strcmp(s.sante,"OK")==0)
             {op++;}
              
              }
         else if (strcmp(s.espece,"coq")==0)
             {co++;
              if(strcmp(s.sante,"OK")==0)
             {oco++;}
               
             }
         else if (strcmp(s.espece,"lapin")==0)
            { l++;
              
             if(strcmp(s.sante,"OK")==0)
             {ol++;} 
             
            }
          else if (strcmp(s.espece,"mouton")==0)
            { m++;
             if(strcmp(s.sante,"OK")==0)
             {om++;} 
            
            }
          else if (strcmp(s.espece,"dindon")==0)
             {d++; 
             if(strcmp(s.sante,"OK")==0)
             {od++;}
            
              
              }
          else if (strcmp(s.espece,"chevre")==0)
             {chev++;
           if(strcmp(s.sante,"OK")==0)
             {ochev++;}
            
              }
          else if (strcmp(s.espece,"canard")==0)
            { can++;
         if(strcmp(s.sante,"OK")==0)
             {ocan++;}
            
             }
          else if (strcmp(s.espece,"ane")==0)
             {a++;
            if(strcmp(s.sante,"OK")==0)
             {oa++;}
            
              
              }
      }


ov=(ov/v)*100;
oc=(oc/c)*100;
op=(op/p)*100;
oco=(oco/co)*100;
ol=(ol/l)*100;
om=(om/m)*100;
od=(od/d)*100;
ochev=(ochev/chev)*100;
ocan=(ocan/can)*100;
oa=(oa/a)*100;

fprintf(fw,"vache %d 40 %.2f%%\n",v,ov);
fprintf(fw,"cheval %d 50 %.2f%%\n",c,oc);
fprintf(fw,"poule %d 0,035 %.2f%%\n",p,op);
fprintf(fw,"coq %d 0,035 %.2f%%\n",co,oco);
fprintf(fw,"lapin %d 0,055 %.2f%%\n",l,ol);
fprintf(fw,"mouton %d 5 %.2f%%\n",m,om);
fprintf(fw,"dindon %d 3 %.2f%%\n",d,od);
fprintf(fw,"chevre %d 3,5 %.2f%%\n",chev,ochev);
fprintf(fw,"canard %d 0,05 %.2f%%\n",can,ocan);
fprintf(fw,"ane %d 36 %.2f%%\n",a,oa);


}

fclose(f);
fclose(fw);

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
 void  aff_nbr(GtkWidget *liste)
{
 enum
{
 EESPECES,
 ENOMBRE,
 EPOIDS_NAISSANCE,
 EPOURCENTAGE_SANTE,
 COLUMNS,
};

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

    char especes[20] ;
    char nombre[20] ;
    char poids__naissance__en__kg[20];
    char pourcentage__sante[20];
   
	store=NULL;
	
	FILE *f;
	
	store=gtk_tree_view_get_model(liste);
	
	if (store==NULL);
{


	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("especes",renderer,"text",EESPECES,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("nombre",renderer,"text",ENOMBRE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("poids__naissance__en__kg",renderer,"text",EPOIDS_NAISSANCE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("pourcentage__sante",renderer,"text",EPOURCENTAGE_SANTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

       
	
       



}

store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("nbrt.txt","r");
if (f==NULL)
{
return;
}
else
{
f=fopen("nbrt.txt","a+");
while(fscanf(f,"%s %s %s %s ",especes,nombre,poids__naissance__en__kg,pourcentage__sante)!=EOF)
	{
		gtk_list_store_append (store,&iter);
		gtk_list_store_set(store,&iter,EESPECES,especes,ENOMBRE,nombre,EPOIDS_NAISSANCE,poids__naissance__en__kg,EPOURCENTAGE_SANTE,pourcentage__sante,-1);
	}

	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void chercher_crit(troupeaux p)
{
troupeaux s;
FILE *f;
FILE *g;
FILE *fw;
fw=fopen("critere1.txt","a+");
remove("critere.txt");
rename("critere1.txt","critere.txt");
fclose(fw);

f=fopen("users.txt","r");
g=fopen("critere.txt","a+");


if((f!=NULL)&&(g!=NULL))
    {
     while(fscanf(f,"%s %s %s %s %s %s %s %s",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age)!=EOF)
       {

          if(strcmp(p.espece,s.espece)==0)
             {

              fprintf(g,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);
            }
        
         else if(strcmp(p.matricule,s.matricule)==0)
             {

              fprintf(g,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);
            }


        else  if(strcmp(p.sexe,s.sexe)==0)
             {

              fprintf(g,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);
            }
  
        else  if(strcmp(p.sante,s.sante)==0)
             {

              fprintf(g,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);
            }
       }}

fclose(f);
fclose(g);

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficher_rech(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

    char matricule[20] ;
    char jour[20] ;
    char mois[20];
    char annee[20];
    char espece[20];
    char sexe[20];
    char sante[20];
    char age[20];
	store=NULL;
	
	FILE *f;
	
	store=gtk_tree_view_get_model(liste);
	
	if (store==NULL);
{

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("matricule",renderer,"text",EMATRICULE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("espece",renderer,"text",EESPECE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        
        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("sante",renderer,"text",ESANTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
   
        renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("age",renderer,"text",EAGE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


       



}

store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("critere.txt","r");
if (f==NULL)
{
return;
}
else
{
f=fopen("critere.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s",matricule,espece,jour,mois,annee,sexe,sante,age)!=EOF)
	{
		gtk_list_store_append (store,&iter);
		gtk_list_store_set(store,&iter,EMATRICULE,matricule,EESPECE,espece,EJOUR,jour,EMOIS,mois,EANNEE,annee,ESEXE,sexe,ESANTE,sante,EAGE,age,-1);
	}

	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
void combobox(GtkWidget *combobox)
{
troupeaux p;
FILE *f ;
f=fopen("users.txt","r");

    if(f!=NULL)
    {
      while(fscanf(f,"%s %s %s %s %s %s %s %s",p.matricule,p.espece,p.jour,p.mois,p.annee,p.sexe,p.sante,p.age)!=EOF)
       {
         gtk_combo_box_append_text(GTK_COMBO_BOX(combobox),(p.matricule));
       }
}
f=fclose(f);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
void supprimeraff(troupeaux s)
{


    FILE *f;
    FILE *fw;
    f=fopen("critere.txt","r");
    fw=fopen("critere2.txt","w");
    troupeaux p;

    if(f!=NULL)
    {
      while(fscanf(f,"%s %s %s %s %s %s %s %s",p.matricule,p.espece,p.jour,p.mois,p.annee,p.sexe,p.sante,p.age)!=EOF)
       {
         if (strcmp(p.matricule,s.matricule)!=0)
        fprintf(fw,"%s %s %s %s %s %s %s %s\n",p.matricule,p.espece,p.jour,p.mois,p.annee,p.sexe,p.sante,p.age);
       }
    }
    fclose(f);
    fclose(fw);
    remove("critere.txt");
    rename("critere2.txt","critere.txt");
}
//////////////////////////////////////////////////////////////////////////////////////////////////
void modifierrech(troupeaux m,troupeaux k)
{
    FILE *f;
    FILE *fw;
    f=fopen("critere.txt","r");
    fw=fopen("critere2.txt","w");
    troupeaux s;
    int x,y;

   
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %s %s %s %s",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age)!=EOF)
       {

           if(strcmp(s.matricule,k.matricule)==0)
           {
           x=atoi(m.annee);
           y=2021-x;
           sprintf(m.age,"%d",y);
       fprintf(fw,"%s %s %s %s %s %s %s %s\n",m.matricule,m.espece,m.jour,m.mois,m.annee,m.sexe,m.sante,m.age);}
       else
        
       fprintf(fw,"%s %s %s %s %s %s %s %s\n",s.matricule,s.espece,s.jour,s.mois,s.annee,s.sexe,s.sante,s.age);

       }
    }
    fclose(f);
    fclose(fw);
    remove("critere.txt");
    rename("critere2.txt","critere.txt");


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////



