#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"

int ajout(plante p)
{
int test=0;

FILE *f;
f=fopen("planning_plante.txt","a+");
if (f!=NULL) 
{
fprintf(f," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte);
test=1;
fclose(f);	
}
return test;
}

