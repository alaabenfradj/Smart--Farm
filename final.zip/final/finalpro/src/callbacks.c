#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#include "absence.h"
#include "animaux.h"
#include "anneeSeche.h"
#include "equip.h"
#include "fnc.h"
#include "fonction.h"
#include "newg.h"
#include "ouvrier.h"
#include "fichier.h"
#include "final.h"
#include "vente.h"

//////////////////////////////////khawla////////////////////////////////////////////////


int x11,y11;
int ex;
int abss,abss1;
char id_c[30];
char NOM_c[30];
char PRE_c[30];
char NUM_c[30];
char ADR_c[30];
char DATE_c[30];
char SPEC_c[30];
char SEXE_c[30];

char id_ab[30];
char date_ab[30];
char absence_ab[30];



void
on_modifiergk_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier c;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
GtkWidget *jr,*mo,*an;
int x1;
GtkToggleButton *male1,*femelle1;
GtkWidget *ouvrir ,*fermer,*treeview2;
fermer=lookup_widget (objet,"afficher_ouvriers");
gtk_widget_destroy(fermer);

ouvrir=create_modifier_donnee();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");

input1= lookup_widget(ouvrir,"entryid_m");
input2= lookup_widget(ouvrir,"entrynom");
input3= lookup_widget(ouvrir,"entryPrenom");
input4= lookup_widget(ouvrir,"entrynum_m");
input5= lookup_widget(ouvrir,"entryadresse_m");

jr=lookup_widget(ouvrir,"spinbutton1");
mo=lookup_widget(ouvrir,"spinbutton2");
an=lookup_widget(ouvrir,"spinbutton3");

input6= lookup_widget(ouvrir,"combobox2");

male1=lookup_widget(ouvrir,"male1");
femelle1=lookup_widget(ouvrir,"femelle1");

gtk_entry_set_text (GTK_ENTRY(input1),id_c);
gtk_entry_set_text (GTK_ENTRY(input2),NOM_c);
gtk_entry_set_text (GTK_ENTRY(input3),PRE_c);
gtk_entry_set_text (GTK_ENTRY(input4),NUM_c);
gtk_entry_set_text (GTK_ENTRY(input5),ADR_c);

char cj[30],cm[30],ca[30];
cj[0]=DATE_c[0];cj[1]=DATE_c[1];
cm[0]=DATE_c[3];cm[1]=DATE_c[4];
ca[0]=DATE_c[6];ca[1]=DATE_c[7];ca[2]=DATE_c[8];ca[3]=DATE_c[9];
int j=atoi(cj);
int m=atoi(cm);
int a=atoi(ca);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(jr),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mo),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(an),a);

if(strcmp(SPEC_c,"veuiller_croissance")==0)x1=0;		
if(strcmp(SPEC_c,"les_produits_derives")==0) x1=1;                
if(strcmp(SPEC_c,"recolter_lesgumes")==0)  x1=2 ;             
if(strcmp(SPEC_c,"recolter_fruits")==0) x1=3;   

gtk_combo_box_set_active(GTK_COMBO_BOX(input6),x1);

if (strcmp(SEXE_c,"male")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(male1), TRUE);
if (strcmp(SEXE_c,"femelle")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(femelle1), TRUE);


}


void
on_supprimergk_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ouvrir,*fermer,*treeview2;

fermer=lookup_widget (objet,"afficher_ouvriers");
gtk_widget_destroy(fermer);

ouvrir=create_supprimer_ouvrier();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");

GtkWidget *input1,*input2,*input3,*input4;

input1=lookup_widget(ouvrir,"supp_nom");
input2=lookup_widget(ouvrir,"supp_prenom");
input3=lookup_widget(ouvrir,"supp_specialite");
input4=lookup_widget(ouvrir,"supp_id");

gtk_label_set_text(GTK_LABEL(input1),NOM_c);
gtk_label_set_text(GTK_LABEL(input2),PRE_c);
gtk_label_set_text(GTK_LABEL(input3),SPEC_c);
gtk_label_set_text(GTK_LABEL(input4),id_c);
}


void
on_deconnexiong_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_menu();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_ouvriers");
gtk_widget_destroy (fermer);
}


void
on_ajouterk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_ajouter_ouvrier();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_ouvriers");
gtk_widget_destroy (fermer);
}


void
on_t_absence_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_afficher_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_ouvriers");
gtk_widget_destroy (fermer);
}


void
on_treeview2k_row_activated             (GtkWidget     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ID;
gchar* nom;
gchar* prenom;
gchar* numero;
gchar* adresse;
gchar* date;
gchar* specialite;
gchar* sexe;


ouvrier c;
GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));

gtk_tree_model_get_iter(model,&iter,path);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ID,1,&nom,2,&prenom,3,&numero,4,&adresse,5,&date,6,&specialite,7,&sexe,-1);

strcpy(id_c,ID);
strcpy(NOM_c,nom);
strcpy(PRE_c,prenom);
strcpy(NUM_c,numero);
strcpy(ADR_c,adresse);
strcpy(DATE_c,date);
strcpy(SPEC_c,specialite);
strcpy(SEXE_c,sexe);
}
}
void
on_retourak_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ouvrir ,*fermer,*treeview2;

ouvrir=create_afficher_ouvriers();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"ajouter_ouvrier");
gtk_widget_destroy (fermer);
treeview2=lookup_widget(ouvrir,"treeview2");

afficher_ouvriers(treeview2);

}


void
on_validerk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier c;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*output;
GtkWidget *jr,*mo,*an;

char sexe[30]="male";
 char jour[30];
 char mois[30];
 char annee[30];
 char date[30];
output= lookup_widget(objet,"output_aj");
input1= lookup_widget(objet,"entryid");
input2= lookup_widget(objet,"entryNom");
input3= lookup_widget(objet,"entryprenom");
input4= lookup_widget(objet,"entrynum_a");
input5= lookup_widget(objet,"entryadresse_a");
jr= lookup_widget(objet,"jour");
mo= lookup_widget(objet,"mois");
an= lookup_widget(objet,"annee");
input6= lookup_widget(objet,"combobox1");


strcpy(c.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));

strcpy(c.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));

c.date.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
c.date.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mo));
c.date.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));
sprintf(jour,"%d",c.date.jour);
sprintf(mois,"%d",c.date.mois);
sprintf(annee,"%d",c.date.annee);

char cj[30]="0";
char cm[30]="0";
if(strlen(jour)==1)strcat(cj,jour);
else strcpy(cj,jour);
if(strlen(mois)==1)strcat(cm,mois);
else strcpy(cm,mois);
strcpy(date,cj);strcat(date,"/");
strcat(date,cm);strcat(date,"/");
strcat(date,annee);                 

strcpy(c.date1,date);

if (x11==1)
strcpy(sexe,"male");
else if (x11==2)
strcpy(sexe,"femelle");

strcpy(c.sexe,sexe);

int ex;
ex=exist(c.ID);
if (ex==1)
 gtk_label_set_text(GTK_LABEL(output),"L'identifiant existe,changez l'id");
else if ((strcmp(c.ID,"")==0)||(strcmp(c.nom,"")==0)||(strcmp(c.prenom,"")==0)||(strcmp(c.adresse,"")==0)||(strcmp(c.numero,"")==0))
 gtk_label_set_text(GTK_LABEL(output),"Vous devez remplir toutes les cases");
else
	{
ajouter_ouvrier(c);
	 gtk_label_set_text(GTK_LABEL(output),"Ajout réussi!");
	}

}


void
on_retourmk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer,*treeview2;

ouvrir=create_afficher_ouvriers();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"modifier_donnee");
gtk_widget_destroy (fermer);
treeview2=lookup_widget(ouvrir,"treeview2");

afficher_ouvriers(treeview2);
}


void
on_modifiermk_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier c;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*output;
GtkWidget *jr,*mo,*an;

char sexe[30]="male";
 char jour[30];
 char mois[30];
 char annee[30];
 char date[30];
output=lookup_widget(objet,"output_modif");
input1= lookup_widget(objet,"entryid_m");
input2= lookup_widget(objet,"entrynom");
input3= lookup_widget(objet,"entryPrenom");
input4= lookup_widget(objet,"entrynum_m");
input5= lookup_widget(objet,"entryadresse_m");
jr= lookup_widget(objet,"spinbutton1");
mo= lookup_widget(objet,"spinbutton2");
an= lookup_widget(objet,"spinbutton3");
input6= lookup_widget(objet,"combobox2");


strcpy(c.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));

strcpy(c.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));

c.date.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
c.date.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mo));
c.date.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));
sprintf(jour,"%d",c.date.jour);
sprintf(mois,"%d",c.date.mois);
sprintf(annee,"%d",c.date.annee);

char cj[30]="0";
char cm[30]="0";
if(strlen(jour)==1)strcat(cj,jour);
else strcpy(cj,jour);
if(strlen(mois)==1)strcat(cm,mois);
else strcpy(cm,mois);
strcpy(date,cj);strcat(date,"/");
strcat(date,cm);strcat(date,"/");
strcat(date,annee);                 

strcpy(c.date1,date);

if (y11==1)
strcpy(sexe,"male");
else if (y11==2)
strcpy(sexe,"femelle");

strcpy(c.sexe,sexe);

if ((strcmp(c.ID,"")==0)||(strcmp(c.nom,"")==0)||(strcmp(c.prenom,"")==0)||(strcmp(c.adresse,"")==0)||(strcmp(c.numero,"")==0))
 gtk_label_set_text(GTK_LABEL(output),"Vous devez remplir toutes les cases");
else
{
supprimer_ouvrier(c);
ajouter_ouvrier(c);
gtk_label_set_text(GTK_LABEL(output),"Ajout réussi!");
}


}


void
on_button_non_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer,*treeview2;

fermer=lookup_widget (objet,"supprimer_ouvrier");
gtk_widget_destroy(fermer);

ouvrir=create_afficher_ouvriers();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");

afficher_ouvriers(treeview2);
}


void
on_button_oui_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{ 
GtkWidget *input;
ouvrier c;
strcpy(c.ID,id_c);
supprimer_ouvrier(c);
char signe[]="suppression terminée avec succés";
input=lookup_widget(objet,"signe");
gtk_label_set_text(GTK_LABEL(input),signe);
}

void
on_male_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x11=1;
}
}


void
on_femelle_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x11=2;
}
}

void
on_id_g_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier c;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*search_id;

search_id=lookup_widget(objet,"id");

strcpy(id_c,gtk_entry_get_text(GTK_ENTRY(search_id)));

GtkWidget *ouvrir,*treeview2;
ouvrir= lookup_widget(objet, "afficher_ouvriers");
gtk_widget_destroy(ouvrir);

ouvrir=create_afficher_ouvriers();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");
afficher_id(treeview2,id_c);

}

void
on_male1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y11=1;
}
}


void
on_femelle1_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y11=2;
}
}


void
on_retour_supp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer,*treeview2;

fermer=lookup_widget (objet,"supprimer_ouvrier");
gtk_widget_destroy(fermer);

ouvrir=create_afficher_ouvriers();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");
afficher_ouvriers(treeview2);
}


void
on_ajouter_abs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_ajouter_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);
}


void
on_modifier_abs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
absence a;

GtkWidget *input1;
GtkWidget *jr,*mo,*an;

GtkToggleButton *yes1,*no1;
GtkWidget *ouvrir ,*fermer,*treeview3;

ouvrir=create_modifier_absence();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);

yes1=lookup_widget(ouvrir,"yes1");
no1=lookup_widget(ouvrir,"no1");

treeview3=lookup_widget(ouvrir,"treeview3");

input1= lookup_widget(ouvrir,"id_mod_abs");
jr= lookup_widget(ouvrir,"spinbutton7");
mo= lookup_widget(ouvrir,"spinbutton8");
an= lookup_widget(ouvrir,"spinbutton10");

gtk_label_set_text(GTK_LABEL(input1),id_ab);

char aj[30],am[30],aa[30];
aj[0]=date_ab[0];aj[1]=date_ab[1];
am[0]=date_ab[3];am[1]=date_ab[4];
aa[0]=date_ab[6];aa[1]=date_ab[7];aa[2]=date_ab[8];aa[3]=date_ab[9];

int j=atoi(aj);
int m=atoi(am);
int ann=atoi(aa);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(jr),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mo),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(an),ann);

if (strcmp(absence_ab,"0")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(no1), TRUE);
if (strcmp(absence_ab,"1")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(yes1), TRUE);

}


void
on_rech_abs_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
///recherche par annee ou les absences ou id

absence a;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*search;

search=lookup_widget(objet,"entry_abs");

strcpy(id_ab,gtk_entry_get_text(GTK_ENTRY(search)));
strcpy(date_ab,gtk_entry_get_text(GTK_ENTRY(search)));
strcpy(absence_ab,gtk_entry_get_text(GTK_ENTRY(search)));

GtkWidget *ouvrir,*fermer,*treeview3;

ouvrir=lookup_widget (objet,"afficher_abs");
gtk_widget_destroy(ouvrir);

ouvrir=create_afficher_abs();
gtk_widget_show(ouvrir);

treeview3=lookup_widget(ouvrir,"treeview3");
recherche(treeview3,id_ab,absence_ab);

////////
}


void
on_retour_abs_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_afficher_ouvriers();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);
}


void
on_chercher_abs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
//chercher si id existe dans la base de donnee des ouvriers pour ajouter une absence
absence a;
char ident[30];
GtkWidget *search_id,*output;

search_id=lookup_widget(objet,"entry3");
output= lookup_widget(objet,"esist_id_aj");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(search_id)));

ex=exist(ident);
if (ex==1)
gtk_label_set_text(GTK_LABEL(output),"L'identifiant existe");
else
gtk_label_set_text(GTK_LABEL(output),"L'identifiant n'existe pas,changez l'id");
}


void
on_aj_abs_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
absence a;

GtkWidget *input1,*output;
GtkWidget *jr,*mo,*an;

 char abs[30];
 char jour[30];
 char mois[30];
 char annee[30];
 char date[30];

output= lookup_widget(objet,"esist_id_aj");
input1= lookup_widget(objet,"entry3");
jr= lookup_widget(objet,"spinbutton9");
mo= lookup_widget(objet,"spinbutton5");
an= lookup_widget(objet,"spinbutton6");

strcpy(a.Identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));

a.jours= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
a.moiss= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mo));
a.annees= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));
sprintf(jour,"%d",a.jours);
sprintf(mois,"%d",a.moiss);
sprintf(annee,"%d",a.annees);

char cj[30]="0";
char cm[30]="0";
if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);
if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);
strcpy(date,cj);
strcat(date,"/");
strcat(date,cm);
strcat(date,"/");
strcat(date,annee);                 

strcpy(a.Date,date);

if (abss==0)
strcpy(abs,"0");
else if (abss==1)
strcpy(abs,"1");

strcpy(a.Absence,abs);

if (ex==1)
{
//lors de la recherche si le id existe on peut donc ajouter une absence
    ajouter_abs(a);
    gtk_label_set_text(GTK_LABEL(output),"Ajout réussi!");
}
else
//si l'id nexiste pas pas d'ajout
    gtk_label_set_text(GTK_LABEL(output),"L'identifiant n'existe pas,changez l'id");

}


void
on_yes_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
abss=1;
}
}


void
on_no_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
abss=0;
}
}


void
on_yes1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
abss1=1;
}
}


void
on_no1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
abss1=0;
}
}


void
on_mod_absence_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
absence a;

GtkWidget *jr,*mo,*an,*output;
 char identit[30];
 char abs[30];
 char jour[30];
 char mois[30];
 char annee[30];
 char date[30];

jr= lookup_widget(objet,"spinbutton7");
mo= lookup_widget(objet,"spinbutton8");
an= lookup_widget(objet,"spinbutton10");
output= lookup_widget(objet,"id_mod_abs");

strcpy(a.Identifiant,gtk_label_get_text(GTK_LABEL(output)));

a.jours= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
a.moiss= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mo));
a.annees= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));
sprintf(jour,"%d",a.jours);
sprintf(mois,"%d",a.moiss);
sprintf(annee,"%d",a.annees);

//ajouter 0 si la taille du jour est 1 pour faciliter la recherche
char cj[30]="0";
char cm[30]="0";
if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);
if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);
strcpy(date,cj);
strcat(date,"/");
strcat(date,cm);
strcat(date,"/");
strcat(date,annee);                 

strcpy(a.Date,date);

if (abss1==0)
strcpy(abs,"0");
else if (abss1==1)
strcpy(abs,"1");

strcpy(a.Absence,abs);

supprimer_abs(a);
ajouter_abs(a);

}


void
on_supp_abs_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ouvrir,*fermer,*treeview3,*output1,*output2;

ouvrir=create_supprimer_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);

treeview3=lookup_widget(ouvrir,"treeview3");

output1=lookup_widget(ouvrir,"quest");
output2=lookup_widget(ouvrir,"quest_id");

gtk_label_set_text(GTK_LABEL(output1),"voulez-vous vraiment supprimer l'absence de cet identifiant:");
gtk_label_set_text(GTK_LABEL(output2),id_ab);
}


void
on_nonsup_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_supprimer_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);

}


void
on_ouisup_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *output;
absence a;
strcpy(a.Identifiant,id_ab);
supprimer_abs(a);
output=lookup_widget(objet,"signes");
gtk_label_set_text(GTK_LABEL(output),"suppression terminée avec succés");

}


void
on_treeview3k_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* Identifiant;
gchar* Date;
gchar* Absence;

absence a;
GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));

gtk_tree_model_get_iter(model,&iter,path);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&Identifiant,1,&Date,2,&Absence,-1);

strcpy(id_ab,Identifiant);
strcpy(date_ab,Date);
strcpy(absence_ab,Absence);
}
}


void
on_back_ajout_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer,*treeview3;
ouvrir=create_afficher_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"ajouter_abs");
gtk_widget_destroy (fermer);
treeview3=lookup_widget(ouvrir,"treeview3");

afficher_abs(treeview3);
}


void
on_back_modif_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer,*treeview3;
ouvrir=create_afficher_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"modifier_absence");
gtk_widget_destroy (fermer);
treeview3=lookup_widget(ouvrir,"treeview3");

afficher_abs(treeview3);
}


void
on_back_supp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer,*treeview3;
ouvrir=create_afficher_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"supprimer_abs");
gtk_widget_destroy (fermer);
treeview3=lookup_widget(ouvrir,"treeview3");

afficher_abs(treeview3);
}


void
on_actualiserk_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer,*treeview2;

ouvrir=lookup_widget (objet,"afficher_ouvriers");
gtk_widget_destroy(ouvrir);

ouvrir=create_afficher_ouvriers();
gtk_widget_show(ouvrir);

treeview2=lookup_widget(ouvrir,"treeview2");
afficher_ouvriers(treeview2);
}


void
on_actualiser_abs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer,*treeview3;

ouvrir=lookup_widget (objet,"afficher_abs");
gtk_widget_destroy(ouvrir);

ouvrir=create_afficher_abs();
gtk_widget_show(ouvrir);

treeview3=lookup_widget(ouvrir,"treeview3");
afficher_abs(treeview3);
}


void
on_taux_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_Taux();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"afficher_abs");
gtk_widget_destroy (fermer);
}


void
on_rech_taux_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mo,*an,*output;
float t;
mo= lookup_widget(objet,"entry4");
an= lookup_widget(objet,"entry5");
output=lookup_widget(objet,"label100");

char ch[30];
char month[30];
char year[30];

strcpy(month,gtk_entry_get_text(GTK_ENTRY(mo)));
strcpy(year,gtk_entry_get_text(GTK_ENTRY(an)));

t=taux_abs(year,month);

sprintf(ch,"%.2f",t);
gtk_label_set_text(GTK_LABEL(output),ch);

}


void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir ,*fermer;
ouvrir=create_afficher_abs();
gtk_widget_show (ouvrir);
fermer=lookup_widget(objet,"Taux");
gtk_widget_destroy (fermer);
}


//////////////////////////////////khawla////////////////////////////////////////////////



//////////////////////////////////BOSS//////////////////////////////////////////////////



int x,y ;
int idf;
char vmaxi[30];
char vmini[30];
char typef[30];
char etatf[30];
int  jf ,mf,af;
char emplacementf[30];



void
on_inscrire_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE *f=NULL;
	GtkWidget *t7al ,*tsakker;
	GtkWidget *nom , *prenom ,*login ,*mdp;

char nom1 [20];
char prenom1[20];
char login1[20] ;
char mdp1[20];
nom = lookup_widget (objet, "entry_nom_ins");
prenom = lookup_widget (objet, "entry_prenom_ins");
login = lookup_widget (objet, "entry_login_ins");
mdp = lookup_widget (objet, "entry_mdp_ins");

strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(login1,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(mdp1,gtk_entry_get_text(GTK_ENTRY(mdp)));

f=fopen("inscription.txt","a+");

if (f!=NULL)
{
fprintf(f,"%s %s %s %s \n",nom1,prenom1,login1,mdp1);
fclose(f);

}
else 
printf("\n NOT Found");

t7al=create_authentification();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"inscription");
gtk_widget_destroy(tsakker);
}


void
on_connecter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker,*treeview1;
	GtkWidget *login_Gest,*password_Gest;

char login_G[20] ;
char mdp_G[20];
int LOG_yes;

login_Gest=lookup_widget (objet, "entrylogin");
password_Gest=lookup_widget (objet, "entrymdp");

strcpy(login_G,gtk_entry_get_text(GTK_ENTRY(login_Gest)));
strcpy(mdp_G,gtk_entry_get_text(GTK_ENTRY(password_Gest)));
LOG_yes=login_verif(login_G,mdp_G);

	if(LOG_yes==1)
	{

t7al=create_gestion_capteur();
gtk_widget_show(t7al);

tsakker=lookup_widget(objet,"authentification");
gtk_widget_destroy(tsakker);

treeview1=lookup_widget(t7al,"treeview1");
afficher_capteurs(treeview1);
	}
}


void
on_retoursauthentifier_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_treeview1alaa_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gint *id;
gchar *type;
gfloat *valeurmax;
gfloat *valeurmin;
gchar *etat;
gint *jour;
gint *mois;
gint *annee;
gchar *emplacement;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path));
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&type,2,&valeurmax,3,&valeurmin,4,&etat,5,&jour,6,&mois,7,&annee,8,&emplacement,-1);


idf=id;
strcpy(typef,type);

//valeurf=valeur;
strcpy(etatf,etat);
jf=jour;
mf=mois;
af=annee;
strcpy(emplacementf,emplacement);


capteur c ;


}
}


void
on_supprimerg_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_supprimer_capteur();
gtk_widget_show (t7al);

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);


}


void
on_modifierg_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_modifier_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);


}


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_ajouter_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);
}




void
on_retourg_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
GtkWidget *ouvrir ,*fermer;
ouvrir=create_menu();
gtk_widget_show (ouvrir);

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);
}


void
on_butt_cherch_gest_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview1,*in1 ;
	int capt;

GtkWidget *t7al ,*tsakker;
char ident[30];

in1= lookup_widget(objet,"entry4");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(in1)));

capt=atoi(ident);

chercher_capteursbyID(capt);

t7al=create_gestion_capteur();
gtk_widget_show (t7al);

treeview1=lookup_widget(t7al,"treeview1");
afficher_capteurs2(treeview1);

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);

}


void
on_radiobutton2alaa_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;} 
}


void
on_radiobutton1alaa_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;} 
}


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *in1,*in2,*in3,*in4,*in5;
GtkWidget *j,*m,*a;
capteur c;
char valeurD[30],idD[30];


in1= lookup_widget(objet,"entry_identf");//id
in2= lookup_widget(objet,"entry_valeur");//valeurmax
in3= lookup_widget(objet,"combobox7");//etat
in4= lookup_widget(objet,"entry5");//valeurmin
in5= lookup_widget(objet,"combobox10");//Emplacement

j= lookup_widget(objet,"spinbutton1");
m= lookup_widget(objet,"spinbutton2");
a= lookup_widget(objet,"spinbutton3");

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////CONTROL/////////////////////////////////////			
///////////////////////////////////////////////////////////////////////////////////////
if ((strcmp(gtk_entry_get_text(GTK_ENTRY(in1)),"")!= 0) && (strcmp(gtk_entry_get_text(GTK_ENTRY(in2)),"")!= 0)&& (strcmp(gtk_entry_get_text(GTK_ENTRY(in4)),"")!= 0)&&(gtk_combo_box_get_active (GTK_COMBO_BOX(in3)) != -1)&&(gtk_combo_box_get_active (GTK_COMBO_BOX(in5)) != -1)&& (x==1) || (x==2))
{
c.id=atoi(gtk_entry_get_text(GTK_ENTRY(in1)));
c.Vmax=atof(gtk_entry_get_text(GTK_ENTRY(in2)));
c.Vmin=atof(gtk_entry_get_text(GTK_ENTRY(in4)));

strcpy(c.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(in3)));
strcpy(c.emplacement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(in5)));

if (x==1)
strcpy(c.type,"Temperature");
else 
if(x==2)
strcpy(c.type,"Humidite");

c.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
c.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

ajouter_capteur(c);

GtkWidget *t7al ,*tsakker,*treeview1;

t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"ajouter_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);


}
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////CONTROL/////////////////////////////////////			
///////////////////////////////////////////////////////////////////////////////////////
else
{
GtkWidget *in1o,*in2o,*in3o,*in4o,*in5o,*label,*label2;
in1o= lookup_widget(objet,"entry_identf");
in2o= lookup_widget(objet,"entry_valeur");
in3o= lookup_widget(objet,"combobox7");
in4o= lookup_widget(objet,"entry5");
in5o= lookup_widget(objet,"combobox10");

label=lookup_widget (objet,"label145");
label2=lookup_widget (objet,"label_etat");

if (strcmp(gtk_entry_get_text(GTK_ENTRY(in1o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in1o),"Obligatoire");
}
if (strcmp(gtk_entry_get_text(GTK_ENTRY(in2o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in2o),"Obligatoire");
}
if (strcmp(gtk_entry_get_text(GTK_ENTRY(in4o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in4o),"Obligatoire");
}

if (gtk_combo_box_get_active (GTK_COMBO_BOX(in5o)) == -1)
{
gtk_label_set_text(GTK_LABEL(label),"Obligatoire");
}

if (gtk_combo_box_get_active (GTK_COMBO_BOX(in3o)) == -1)
{
gtk_label_set_text(GTK_LABEL(label2),"Obligatoire");
}


}


}


void
on_retoura_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker,*treeview1;

t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"ajouter_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);
}


void
on_supprimer_capteur_show              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
char ids[50];
char labelsh[50];
strcpy(labelsh,"Capteur : ");
sprintf(ids,"%d",idf);
strcat(labelsh,ids);
label=lookup_widget (objet,"label_supp_non");
gtk_label_set_text(GTK_LABEL(label),labelsh);
}


void
on_annuler_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"supprimer_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);
}


void
on_ok_supprimer_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
int identifiant;
int jour ;

identifiant=idf ;
jour=jf;

capteur c ;
supprimer_capteur(identifiant,jour,mf,af,c);


GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"supprimer_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);

}


void
on_modifier_capteur_show               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *labelid,*labelvaleur,*labeltype,*labeletat,*in3,*in6;
char ids[50];

sprintf(ids,"%d",idf);
labelid=lookup_widget (objet,"entry1");
gtk_entry_set_text(GTK_ENTRY(labelid),ids);




if (strcmp(etatf,"PANNE")==0)
{
in3= lookup_widget(objet,"combobox8");
gtk_combo_box_set_active(GTK_COMBO_BOX(in3), 0);
}
else 
{
in3= lookup_widget(objet,"combobox8");
gtk_combo_box_set_active(GTK_COMBO_BOX(in3), 1);
}

if (strcmp(emplacementf,"Serre1")==0)
{
in6= lookup_widget(objet,"combobox11");
gtk_combo_box_set_active(GTK_COMBO_BOX(in6), 0);
}
else
 if(strcmp(emplacementf,"Serre2")==0)
{
in6= lookup_widget(objet,"combobox11");
gtk_combo_box_set_active(GTK_COMBO_BOX(in6), 1);
}
else
{
in6= lookup_widget(objet,"combobox11");
gtk_combo_box_set_active(GTK_COMBO_BOX(in6), 2);
}




GtkWidget *j,*m,*a;

j= lookup_widget(objet,"spinbutton4");
m= lookup_widget(objet,"spinbutton5");
a= lookup_widget(objet,"spinbutton6");

gtk_spin_button_set_value(GTK_SPIN_BUTTON(j),jf);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(m),mf);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(a),af);



}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
y=1;
} 
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
y=2;
} 
}


void
on_ok_modifier_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

int identifiant;
int jour ;
capteur c ;
identifiant=idf ;
jour=jf;


GtkWidget *in1,*in2,*in3,*in4,*in5;
GtkWidget *j,*m,*a;
capteur c2 ;

in1= lookup_widget(objet,"entry1");
in2= lookup_widget(objet,"entry2");
in4= lookup_widget(objet,"entry6");
in3= lookup_widget(objet,"combobox8");
in5= lookup_widget(objet,"combobox11");
j= lookup_widget(objet,"spinbutton4");
m= lookup_widget(objet,"spinbutton5");
a= lookup_widget(objet,"spinbutton6");

if ( (strcmp(gtk_entry_get_text(GTK_ENTRY(in2)),"")!= 0)&& (strcmp(gtk_entry_get_text(GTK_ENTRY(in4)),"")!= 0)&& (y==1) || (y==2))
{



c2.id=atoi(gtk_entry_get_text(GTK_ENTRY(in1)));
c2.Vmax=atof(gtk_entry_get_text(GTK_ENTRY(in2)));
c2.Vmin=atof(gtk_entry_get_text(GTK_ENTRY(in4)));
strcpy(c2.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(in3)));
strcpy(c2.emplacement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(in5)));

if (y==1)
strcpy(c2.type,"Temperature");
else 
if(y==2)
strcpy(c2.type,"Humidite");

c2.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
c2.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c2.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

ajouter_capteur(c2);
supprimer_capteur(identifiant,jour,mf,af,c);

GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"modifier_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);

}
else
{
GtkWidget *in1o,*in2o,*in3o,*in4o,*in5o;
in1o= lookup_widget(objet,"entry1");
in2o= lookup_widget(objet,"entry2");
in4o= lookup_widget(objet,"entry6");
in3o= lookup_widget(objet,"combobox8");
in5o= lookup_widget(objet,"combobox11");

if (strcmp(gtk_entry_get_text(GTK_ENTRY(in2o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in2o),"Obligatoire");
}
if (strcmp(gtk_entry_get_text(GTK_ENTRY(in4o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in4o),"Obligatoire");
}

}

}


void
on_retour_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"modifier_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);
}


void
on_ok_ajout_valeur_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*in2,*j,*m,*a;

capteur c2 ;
char val_max[30];
char val_min[30];
in1= lookup_widget(objet,"entry_valeur_ajout_valeur");
strcpy(val_max,gtk_entry_get_text(GTK_ENTRY(in1)));

in2= lookup_widget(objet,"entry7");
strcpy(val_min,gtk_entry_get_text(GTK_ENTRY(in2)));

if ( (strcmp(gtk_entry_get_text(GTK_ENTRY(in1)),"")!= 0)&& (strcmp(gtk_entry_get_text(GTK_ENTRY(in2)),"")!= 0))
{
c2.id=idf;

c2.Vmax=atof(val_max);
c2.Vmin=atof(val_min);

strcpy(c2.etat,etatf);

strcpy(c2.type,typef);

strcpy(c2.emplacement,emplacementf);

j= lookup_widget(objet,"spinbutton7");
m= lookup_widget(objet,"spinbutton8");
a= lookup_widget(objet,"spinbutton9");

c2.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
c2.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c2.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));


ajouter_capteur(c2);

GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"ajout_valeur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);


}
else 
{
GtkWidget *in1o,*in2o;
in1o= lookup_widget(objet,"entry_valeur_ajout_valeur");
in2o= lookup_widget(objet,"entry7");


if (strcmp(gtk_entry_get_text(GTK_ENTRY(in1o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in1o),"Obligatoire");
}
if (strcmp(gtk_entry_get_text(GTK_ENTRY(in2o)),"")== 0)
{
gtk_entry_set_text(GTK_ENTRY(in2o),"Obligatoire");
}
}

}

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker,*treeview1;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"ajout_valeur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");

afficher_capteurs(treeview1);
}


void
on_ajout_valeur_show                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *j,*m,*a;

j= lookup_widget(objet,"spinbutton7");
m= lookup_widget(objet,"spinbutton8");
a= lookup_widget(objet,"spinbutton9");

gtk_spin_button_set_value(GTK_SPIN_BUTTON(j),jf);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(m),mf);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(a),af);


}


void
on_retour_alarmant_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1,*t7al,*tsakker;
tsakker=lookup_widget(objet,"Alarmants");
gtk_widget_destroy (tsakker);


t7al=create_gestion_capteur();
gtk_widget_show (t7al);


treeview1=lookup_widget(t7al,"treeview1");
afficher_capteurs(treeview1);
}


void
on_alarmants_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

/////////////////////////////////////////////////////////////////////////////

GtkWidget *treeview2,*treeview3,*t7al,*tsakker;
tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);


t7al=create_Alarmants();
gtk_widget_show (t7al);

treeview2=lookup_widget(t7al,"treeview2");
afficher_capteurs_temp(treeview2);

/////////////////////////////////////////////////////////////////////////////

treeview3=lookup_widget(t7al,"treeview3");
afficher_capteurs_hum(treeview3);





}


void
on_ajout_val_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al,*tsakker;

t7al=create_ajout_valeur();
gtk_widget_show (t7al);

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);

}


void
on_refrech_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1,*t7al,*tsakker;

t7al=create_gestion_capteur();
gtk_widget_show (t7al);

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);

treeview1=lookup_widget(t7al,"treeview1");
afficher_capteurs(treeview1);
}


void
on_chercher_diff_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*treeview1,*t7al,*tsakker;
char etat[30];

in1= lookup_widget(objet,"combobox9");
strcpy(etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(in1)));
if (strcmp(etat,"PANNE")==0){
    capteur c;
    FILE *f;
    FILE *d;
    f=fopen("capteur.txt","r");
    d=fopen("diffectueux.txt","w");
    if (f!=NULL)
    {
        while(fscanf(f,"%d %s %f %f %s %d %d %d %s",&c.id,c.type,&c.Vmax,&c.Vmin,c.etat,&c.d.jour,&c.d.mois,&c.d.annee,c.emplacement)!=EOF)
            {
                if (strcmp("PANNE",c.etat)==0)
                  {
                    fprintf(d,"%d %s %.2f %.2f %s %d %d %d %s\n",c.id,c.type,c.Vmax,c.Vmin,c.etat,c.d.jour,c.d.mois,c.d.annee,c.emplacement);
                  }
            }
    }
    else
    printf("Erreur");

    fclose(f);
    fclose(d);


t7al=create_gestion_capteur();
gtk_widget_show (t7al);

treeview1=lookup_widget(t7al,"treeview1");


tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);

afficher_capteurs3(treeview1);
}

else 
{

 capteur c;
    FILE *f;
    FILE *k;
    f=fopen("capteur.txt","r");
    k=fopen("ok.txt","w");
    if (f!=NULL)
    {
       while(fscanf(f,"%d %s %f %f %s %d %d %d %s",&c.id,c.type,&c.Vmax,&c.Vmin,c.etat,&c.d.jour,&c.d.mois,&c.d.annee,c.emplacement)!=EOF)
            {
                if (strcmp("OK",c.etat)==0)
                  {
                     fprintf(k,"%d %s %.2f %.2f %s %d %d %d %s\n",c.id,c.type,c.Vmax,c.Vmin,c.etat,c.d.jour,c.d.mois,c.d.annee,c.emplacement);
                  }
            }
    }
    else
    printf("Erreur");

    fclose(f);
    fclose(k);


t7al=create_gestion_capteur();
gtk_widget_show (t7al);

treeview1=lookup_widget(t7al,"treeview1");

tsakker=lookup_widget(objet,"gestion_capteur");
gtk_widget_destroy (tsakker);

afficher_capteurs4(treeview1);


}

}





void
on_gestion_capteur_show                (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *in1 ;
in1= lookup_widget(objet,"entry4");
gtk_entry_set_text(GTK_ENTRY(in1),"Chercher par ID");

GtkWidget *label;




}






void
on_cheralarm_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

int jourt,moist,anneet;

GtkWidget *treeview1,*treeview3,*t7al,*tsakker,*ja,*ma,*aa;

ja= lookup_widget(objet,"ja");
ma= lookup_widget(objet,"ma");
aa= lookup_widget(objet,"aa");


jourt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ja));
moist=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ma));
anneet=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));

chercher_alamantes_temp(jourt,moist,anneet);

t7al=create_Alarmants();
gtk_widget_show (t7al);



tsakker=lookup_widget(objet,"Alarmants");
gtk_widget_destroy (tsakker);



treeview3=lookup_widget(t7al,"treeview2");
afficher_capteurs_temp_alarm(treeview3);


treeview1=lookup_widget(t7al,"treeview3");
afficher_capteurs_hum(treeview1);

}


void
on_cherHum_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

int jourt,moist,anneet;

GtkWidget *treeview2,*treeview3,*t7al,*tsakker,*ja,*ma,*aa;

ja= lookup_widget(objet,"spinbutton10");
ma= lookup_widget(objet,"spinbutton11");
aa= lookup_widget(objet,"spinbutton12");


jourt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ja));
moist=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ma));
anneet=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));

chercher_alamantes_humid(jourt,moist,anneet);

t7al=create_Alarmants();
gtk_widget_show (t7al);



tsakker=lookup_widget(objet,"Alarmants");
gtk_widget_destroy (tsakker);

treeview3=lookup_widget(t7al,"treeview3");
afficher_capteurs_hum_alarm(treeview3);

treeview2=lookup_widget(t7al,"treeview2");
afficher_capteurs_temp(treeview2);



}

void
on_plusalarm_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview2,*treeview1,*t7al,*tsakker,*ja,*ma,*aa;

chercher_plus_alamantes_temp();
chercher_plus_alamantes_hum();
t7al=create_Alarmants();
gtk_widget_show (t7al);



tsakker=lookup_widget(objet,"Alarmants");
gtk_widget_destroy (tsakker);


treeview1=lookup_widget(t7al,"treeview3");
afficher_capteurs_hum_plus_alarm(treeview1);

treeview2=lookup_widget(t7al,"treeview2");
afficher_capteurs_temp_plus_alarm(treeview2);

}


void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview2,*treeview3,*t7al,*tsakker;

t7al=create_Alarmants();
gtk_widget_show (t7al);

tsakker=lookup_widget(objet,"Alarmants");
gtk_widget_destroy (tsakker);



treeview2=lookup_widget(t7al,"treeview2");
afficher_capteurs_temp(treeview2);


treeview3=lookup_widget(t7al,"treeview3");
afficher_capteurs_hum(treeview3);
}


void
on_def_marque_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
label=lookup_widget (objet,"labeldef");



marquedef();


capteur c;

int A=0,B=0,C=0;

FILE *f=fopen("marquedef.txt","r");
if(f==NULL)
return;

else
{
while(fscanf(f,"%d %s %f %f %s %d %d %d %s",&c.id,c.type,&c.Vmax,&c.Vmin,c.etat,&c.d.jour,&c.d.mois,&c.d.annee,c.emplacement)!=EOF)
{
if(strcmp("FarmTRX",c.emplacement)==0)
A++;
if(strcmp("MC_Sieve_Sensor",c.emplacement)==0)
B++;
if(strcmp("TOPCON",c.emplacement)==0)
C++;
}

   if ( A > B && A > C )
     gtk_label_set_text(GTK_LABEL(label),"FarmTRX");
   else if ( B > A && B > C )
      gtk_label_set_text(GTK_LABEL(label),"MC_Sieve_Sensor");
   else  
      gtk_label_set_text(GTK_LABEL(label),"TOPCON");
   


}


}

//////////////////////////////////BOSS//////////////////////////////////////////////////

//////////////////////////////////Tarek//////////////////////////////////////////////////



int x,z;

char reft[30];
char desigt[30];
char marquet[30];
char etatt[30];
char datet[30];



void
on_retourstarek_clicked                     (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_equipements,*supprimer_equipement,*treeview5;
gestion_des_equipements=create_gestion_des_equipements() ;
supprimer_equipement=lookup_widget(objet_graphique,"supprimer_equipement");
gtk_widget_destroy(supprimer_equipement);
gtk_widget_show(gestion_des_equipements);
treeview5=lookup_widget(gestion_des_equipements,"treeview5");

afficher_equipement(treeview5);
}


void
on_supprimerstarek_clicked                  (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *in1,*label;
	equipement e;



strcpy(e.Ref,reft);
supprimer_equipement(e);

label=lookup_widget (objet_graphique,"label196");
gtk_label_set_text(GTK_LABEL(label),"****VOTRE SUPPRESSION A ETE EFFECTUE AVEC SUCCES****");
}




void
on_ajoutergtarek_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ajouter_equipement,*gestion_des_equipements;
ajouter_equipement=create_ajouter_equipement() ;
gestion_des_equipements=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(gestion_des_equipements);
gtk_widget_show(ajouter_equipement);
}


void
on_afficherg_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}



void
on_Modifiergtarek_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifier_equipement,*gestion_des_equipements;
modifier_equipement=create_modifier_equipement() ;
gestion_des_equipements=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(gestion_des_equipements);
gtk_widget_show(modifier_equipement);
}



void
on_supprimergtarek_clicked                  (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *supprimer_equipement,*gestion_des_equipements;
supprimer_equipement=create_supprimer_equipement() ;
gestion_des_equipements=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(gestion_des_equipements);
gtk_widget_show(supprimer_equipement);
}



void
on_retouratarek_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_equipements,*ajouter_equipement,*treeview5;
gestion_des_equipements=create_gestion_des_equipements() ;
ajouter_equipement=lookup_widget(objet_graphique,"ajouter_equipement");
gtk_widget_hide(ajouter_equipement);
gtk_widget_show(gestion_des_equipements);
treeview5=lookup_widget(gestion_des_equipements,"treeview5");

afficher_equipement(treeview5);
}


void
on_ajouteratarek_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *ref ,*Designation, *Marque,*Etat,*a,*b,*c,*label;
char Ref[30];
char designation[30];
char marque[30];
char etat[30];
char date_achat[30],sjour[30],smois[30],sannee[30];
equipement e;
int jour, mois,annee;

ref = lookup_widget (objet_graphique,"entryDesignation");
Designation = lookup_widget (objet_graphique, "entryReference");
Marque = lookup_widget (objet_graphique, "combobox1");

if(x==1)
strcpy(e.etat,"OK");
else
if(x==2)
strcpy(e.etat,"EnPanne");

a = lookup_widget (objet_graphique, "jour");
b = lookup_widget (objet_graphique, "mois");
c = lookup_widget (objet_graphique, "annee");

strcpy(e.Ref, gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(e.designation, gtk_entry_get_text(GTK_ENTRY(Designation)));
strcpy(e.marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(Marque)));


jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(b));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(c));

sprintf(sjour,"%d/", jour);
sprintf(smois,"%d/", mois);
sprintf(sannee,"%d", annee);

strcat(date_achat, sjour);
strcat(date_achat, smois);
strcat(date_achat, sannee);

strcpy(e.date_achat,date_achat);

ajouter_equipement(e);

label=lookup_widget (objet_graphique,"label111113");
gtk_label_set_text(GTK_LABEL(label),"****VOTRE AJOUT A ETE EFFECTUE AVEC SUCCES****");




}


void
on_retourmo_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_equipements,*modifier_equipement,*treeview5;
gestion_des_equipements=create_gestion_des_equipements() ;
modifier_equipement=lookup_widget(objet_graphique,"modifier_equipement");
gtk_widget_hide(modifier_equipement);
gtk_widget_show(gestion_des_equipements);
treeview5=lookup_widget(gestion_des_equipements,"treeview5");

afficher_equipement(treeview5);
}


void
on_enregistrermo_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *tak,*label;
	equipement e22;


tak= lookup_widget(objet_graphique,"entry3");
strcpy(e22.Ref,reft);
supprimer_equipement(e22);

FILE *f=NULL;
GtkWidget *ref ,*Designation, *Marque,*Etat,*a,*b,*c;
char Ref[30];
char designation[30];
char marque[30];
char etat[30];
char date_achat[30],sjour[30],smois[30],sannee[30];
equipement e;
int jour, mois,annee;

ref = lookup_widget (objet_graphique,"entrymodesignation");
Designation = lookup_widget (objet_graphique, "entrymorefence");
Marque = lookup_widget (objet_graphique, "combobox2");

if(z==1)
strcpy(e.etat,"OK");
else
if(z==2)
strcpy(e.etat,"EnPanne");

a = lookup_widget (objet_graphique, "jourmo");
b = lookup_widget (objet_graphique, "moismo");
c = lookup_widget (objet_graphique, "anneemo");

strcpy(e.Ref, gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(e.designation, gtk_entry_get_text(GTK_ENTRY(Designation)));
strcpy(e.marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(Marque)));


jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(b));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(c));

sprintf(sjour,"%d/", jour);
sprintf(smois,"%d/", mois);
sprintf(sannee,"%d", annee);

strcat(date_achat, sjour);
strcat(date_achat, smois);
strcat(date_achat, sannee);

strcpy(e.date_achat,date_achat);

ajouter_equipement(e);

label=lookup_widget (objet_graphique,"label111114");
gtk_label_set_text(GTK_LABEL(label),"****VOTRE INFORMATIONS A ETE MODIFIEE AVEC SUCCES****");


}

void
on_retourliste_clicked                 (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_equipements,*afficher_equipement;
gestion_des_equipements=create_gestion_des_equipements() ;
afficher_equipement=lookup_widget(objet_graphique,"afficher_equipement");
gtk_widget_hide(afficher_equipement);
gtk_widget_show(gestion_des_equipements);
}






void
on_cherchergtarek_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output,*output1,*output2,*output3,*output4,*output5,*output6;

char ref[30];

equipement e;

GtkWidget *gestion_des_equipements,*hide,*treeview5;

input1=lookup_widget(objet_graphique,"entry1");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input1)));
chercher_equipement2(ref);
hide=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(hide);

gestion_des_equipements=create_gestion_des_equipements() ;
gtk_widget_show(gestion_des_equipements);

treeview5=lookup_widget(gestion_des_equipements,"treeview5");
chercher_equipement(treeview5);

chercher_equipement2(ref);


}




/*output=lookup_widget(objet_graphique,"label111115");
v=chercher_equipement(ref);

if(v==1)
{

gtk_label_set_text(GTK_LABEL(output),"l'equipement existe");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"l'equipement inexistant");
}
*/



void
on_radiobuttonokp_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}


void
on_radiobuttonpa_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=1;}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=2;}
}

/*
void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* refft;
gchar* dest;
gchar* marqt;
gchar* etatee;
gchar* datee;


GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path));
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&refft,1,&dest,2,&marqt,3,&etatee,4,&datee,-1);

strcpy(reft,refft);
strcpy(desigt,dest);
strcpy(marquet,marqt);
strcpy(etatt,etatee);
strcpy(datet,datee);

}

}

*/















void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* refft;
gchar* dest;
gchar* marqt;
gchar* etatee;
gchar* datee;


GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path));
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&refft,1,&dest,2,&marqt,3,&etatee,4,&datee,-1);

strcpy(reft,refft);
strcpy(desigt,dest);
strcpy(marquet,marqt);
strcpy(etatt,etatee);
strcpy(datet,datee);

}
}


void
on_D__ffectueux_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *gestion_des_equipements,*hide,*treeview5;


hide=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(hide);

gestion_des_equipements=create_gestion_des_equipements() ;
gtk_widget_show(gestion_des_equipements);

treeview5=lookup_widget(gestion_des_equipements,"treeview5");
deffect();
afficher_equipement2(treeview5);








}


void
on_button1tarek_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_equipements,*hide,*treeview5;


hide=lookup_widget(objet_graphique,"gestion_des_equipements");
gtk_widget_hide(hide);

gestion_des_equipements=create_gestion_des_equipements() ;
gtk_widget_show(gestion_des_equipements);

treeview5=lookup_widget(gestion_des_equipements,"treeview5");

afficher_equipement(treeview5);
}


void
on_button2tarek_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *label;
label=lookup_widget (objet_graphique,"label111121");



marquedef22();


equipement e;

int A=0,B=0,C=0;

FILE *f=fopen("marquedef.txt","r");
if(f==NULL)
return;

else
{
while(fscanf(f,"%s %s %s %s %s \n",e.Ref,e.designation,e.marque,e.etat,e.date_achat)!=EOF)
{
if(strcmp("Fendt",e.marque)==0)
A++;
if(strcmp("Claas",e.marque)==0)
B++;
if(strcmp("John_Deere",e.marque)==0)
C++;
}

   if ( A > B && A > C )
     gtk_label_set_text(GTK_LABEL(label),"Fendt");
   else if ( B > A && B > C )
      gtk_label_set_text(GTK_LABEL(label),"Claas");
   else  
      gtk_label_set_text(GTK_LABEL(label),"John_Deere");
   


}


}

//////////////////////////////////Tarek//////////////////////////////////////////////////

//////////////////////////////////youssef//////////////////////////////////////////////////


int xa=0;
int ba=0;
int ma=0;
int mb=0;
int cbo=0;
int cbs=0;
int ro=1;
int rs=1;

troupeaux inter;




void
on_ajoutery_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_aff;
GtkWidget *fenetre_ajouter;


fenetre_aff=lookup_widget(objet,"affichage");
gtk_widget_destroy(fenetre_aff);
fenetre_ajouter=lookup_widget(objet,"ajouter");
fenetre_ajouter= create_ajouter ();
gtk_widget_show(fenetre_ajouter);

}


void
on_modifiergy_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_aff;
GtkWidget *fenetre_modif;



fenetre_aff=lookup_widget(objet,"affichage");
gtk_widget_destroy(fenetre_aff);
fenetre_modif=lookup_widget(objet,"modifierg");
fenetre_modif= create_modifier();
gtk_widget_show(fenetre_modif);
}


void
on_retourgy_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *t7al ,*tsakker;
GtkWidget *ouvrir ,*fermer;
ouvrir=create_menu();
gtk_widget_show (ouvrir);

tsakker=lookup_widget(objet,"affichage");
gtk_widget_destroy (tsakker);

}


void
on_supprimergy_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
GtkWidget *fenetre_aff;

supprimer(inter);
fenetre_aff=lookup_widget(objet,"affichage");
gtk_widget_destroy(fenetre_aff);
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);



}


void
on_retouray_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_ajout=lookup_widget(objet,"ajouter");
gtk_widget_destroy(fenetre_ajout);


fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);

}


void
on_validery_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
troupeaux p;
GtkWidget *fenetre_ajout;
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
char j[50];
char m[50];
char a[50];
int jour,mois,annee;



fenetre_ajout=lookup_widget(objet,"ajouter");
input=lookup_widget(objet,"matricule");
input1=lookup_widget(objet,"combobox1");
input2=lookup_widget(objet,"spinbutton4");
input3=lookup_widget(objet,"spinbutton5");
input4=lookup_widget(objet,"spinbutton6");
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
sprintf(j,"%d",jour);
sprintf(m,"%d",mois);
sprintf(a,"%d",annee);
strcpy(p.matricule,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(p.espece,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(p.jour,j);
strcpy(p.mois,m);
strcpy(p.annee,a);

 if(xa==0)
{strcpy(p.sexe,"male");
xa=0; }
else if(xa==1)
{strcpy(p.sexe,"femelle"); 
xa=0;}

 if(ba==0)
{strcpy(p.sante,"OK"); 
ba=0;}
else if(ba==1)
{strcpy(p.sante,"NOT_OK"); 
ba=0;}


ajouter(p);

GtkWidget *fenetre_ajou;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_ajou=lookup_widget(objet,"ajouter");

gtk_widget_destroy(fenetre_ajou);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);

}





void
on_modifiermy_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{


troupeaux p;
GtkWidget *fenetre_modif;
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
char j[50];
char m[50];
char a[50];
int jour,mois,annee;



fenetre_modif=lookup_widget(objet,"modifier");
input=lookup_widget(objet,"entry_matricule_modif");
input1=lookup_widget(objet,"combobox2");
input2=lookup_widget(objet,"spinbutton1");
input3=lookup_widget(objet,"spinbutton2");
input4=lookup_widget(objet,"spinbutton3");
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
sprintf(j,"%d",jour);
sprintf(m,"%d",mois);
sprintf(a,"%d",annee);
strcpy(p.matricule,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(p.espece,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(p.jour,j);
strcpy(p.mois,m);
strcpy(p.annee,a);

 if(ma==0)
{strcpy(p.sexe,"male");
ma=0; }
else if(ma==1)
{strcpy(p.sexe,"femelle");
ma=0; }

 if(mb==0)
{strcpy(p.sante,"OK"); 
mb=0;}
else if(mb==1)
{strcpy(p.sante,"NOT_OK");
mb=0; }



modifier(p,inter);

GtkWidget *fenetre_modifier;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_modifier=lookup_widget(objet,"modifier");

gtk_widget_destroy(fenetre_modif);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);


}


void
on_retourmy_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_modif=lookup_widget(objet,"modifier");

gtk_widget_destroy(fenetre_modif);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);


}



void
on_button1_inscription_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *login,*pw, *windowAuth;
char login1[20];
char passw[20];
login = lookup_widget (button,"entry11_usernam");
pw = lookup_widget (button,"entry12_mdp");
strcpy(login1, gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(passw, gtk_entry_get_text(GTK_ENTRY(pw)));
//ouvrir le fichier
f=fopen("utilisateur.txt","a");
if (f!=NULL)
{
fprintf(f,"%s %s \n",login1,passw);
fclose(f);
}
else
printf("\n not found");

windowAuth=create_menu();
gtk_widget_show (windowAuth);
}


void
on_option_specialite_ajout_changed     (GtkOptionMenu   *optionmenu,
                                        gpointer         user_data)
{

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* matricule;
gchar* espece;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* sexe;
gchar* sante;




GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&matricule,1,&espece,2,&jour,3,&mois,4,&annee,5,&sexe,6,&sante,-1);
strcpy(inter.matricule,matricule);
strcpy(inter.espece,espece);
strcpy(inter.jour,jour);
strcpy(inter.mois,mois);
strcpy(inter.annee,annee);
strcpy(inter.sexe,sexe);
strcpy(inter.sante,sante);


}



}



void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{xa=0;}
}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{xa=1;}
}




void
on_Retoury_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_nb;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_nb=lookup_widget(objet,"nb");

gtk_widget_destroy(fenetre_nb);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}


void
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{


GtkWidget *fenetre_nb;
GtkWidget *fenetre_aff;
GtkWidget *treeview2;
fenetre_aff=lookup_widget(objet,"affichage");
gtk_widget_destroy(fenetre_aff);
nb_troupeaux_type( );
fenetre_nb=lookup_widget(objet,"nb");
fenetre_nb= create_nb ();
gtk_widget_show(fenetre_nb);

treeview2= lookup_widget(fenetre_nb,"treeview2");
 aff_nbr(treeview2);

}



void
on_button4_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *fenetre_aff;

fenetre_aff=lookup_widget(objet,"affichage");
gtk_widget_destroy(fenetre_aff);
fenetre_crit=lookup_widget(objet,"critere");
fenetre_crit= create_critere ();
gtk_widget_show(fenetre_crit);
}


void
on_button6_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_crit=lookup_widget(objet,"critere");

gtk_widget_destroy(fenetre_crit);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}



void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ba=1;}
}


void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ba=0;}
}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ma=0;}
}


void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ma=1;}
}


void
on_radiobutton13_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{mb=1;}
}


void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{mb=0;}
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* matricule;
gchar* espece;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* sexe;
gchar* sante;




GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&matricule,1,&espece,2,&jour,3,&mois,4,&annee,5,&sexe,6,&sante,-1);
strcpy(inter.matricule,matricule);
strcpy(inter.espece,espece);
strcpy(inter.jour,jour);
strcpy(inter.mois,mois);
strcpy(inter.annee,annee);
strcpy(inter.sexe,sexe);
strcpy(inter.sante,sante);


}

}


void
on_checherch_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *fenetre_affrech;

fenetre_affrech=lookup_widget(objet,"affichage_recherche");
gtk_widget_destroy(fenetre_affrech);
fenetre_crit=lookup_widget(objet,"critere");
fenetre_crit= create_critere ();
gtk_widget_show(fenetre_crit);
}


void
on_button8_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_affrech;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_affrech=lookup_widget(objet,"affichage_recherche");

gtk_widget_destroy(fenetre_affrech);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}
void
on_modifier_show                       (GtkWidget       *widget,
                                        gpointer         user_data);


void
on_rech_mat_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *Recherche_matricu;


fenetre_crit=lookup_widget(objet,"critere");
gtk_widget_destroy(fenetre_crit);
Recherche_matricu=lookup_widget(objet,"Recherche_matricule");
Recherche_matricu=create_recherche_matricule ();
gtk_widget_show (Recherche_matricu);


}


void
on_button10_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *Recherche_espece;

fenetre_crit=lookup_widget(objet,"critere");
gtk_widget_destroy(fenetre_crit);
Recherche_espece=lookup_widget(objet,"Recherche_espece");
Recherche_espece=create_recherche_espece();
  gtk_widget_show (Recherche_espece);
}


void
on_button11_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *recherche_sexe;

fenetre_crit=lookup_widget(objet,"critere");
gtk_widget_destroy(fenetre_crit);
recherche_sexe=lookup_widget(objet,"recherche_sexe");
recherche_sexe=create_recherche_sexe();
  gtk_widget_show (recherche_sexe);
}


void
on_button12_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_crit;
GtkWidget *Recherche_sante;

fenetre_crit=lookup_widget(objet,"critere");
gtk_widget_destroy(fenetre_crit);
Recherche_sante=lookup_widget(objet,"recherche_sante");
Recherche_sante=create_recherche_sante();
  gtk_widget_show (Recherche_sante);
}


void
on_button13_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)

{


troupeaux p;
GtkWidget *fenetre_rechmat;
GtkWidget *fenetre_afficher_recherche;
GtkWidget *treeview3;
GtkWidget *input1;






fenetre_rechmat=lookup_widget(objet,"Recherche_matricule");
input1=lookup_widget(objet,"combobox3");

strcpy(p.matricule,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));



chercher_crit(p);

fenetre_rechmat=lookup_widget(objet,"Recherche_matricule");

gtk_widget_destroy(fenetre_rechmat);
fenetre_afficher_recherche=lookup_widget(objet,"affichage_recherche");
fenetre_afficher_recherche=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher_recherche);


treeview3= lookup_widget(fenetre_afficher_recherche,"treeview3");
afficher_rech(treeview3);


}



void
on_button15_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
troupeaux p;
GtkWidget *fenetre_esp;
GtkWidget *fenetre_afficher_recherche;
GtkWidget *treeview3;
GtkWidget *input1;



fenetre_esp=lookup_widget(objet,"recherche_espece");
input1=lookup_widget(objet,"combobox4");
strcpy(p.espece,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
chercher_crit(p);

fenetre_esp=lookup_widget(objet,"recherche_espece");
gtk_widget_destroy(fenetre_esp);
fenetre_afficher_recherche=lookup_widget(objet,"affichage_recherche");
fenetre_afficher_recherche=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher_recherche);
treeview3= lookup_widget(fenetre_afficher_recherche,"treeview3");
afficher_rech(treeview3);

}


void
on_button16_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechesp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_rechesp=lookup_widget(objet,"recherche_espece");

gtk_widget_destroy(fenetre_rechesp);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}


void
on_button17_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechsexe;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_rechsexe=lookup_widget(objet,"recherche_sexe");

gtk_widget_destroy(fenetre_rechsexe);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}


void
on_button18_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
troupeaux p;
GtkWidget *fenetre_rechsexe;
GtkWidget *fenetre_afficher_recherche;
GtkWidget *treeview3;
GtkWidget *input1;





fenetre_rechsexe=lookup_widget(objet,"recherche_sexe");
if(cbs==0)
{
strcpy(p.sexe,"male");
cbs==0;}
else if(cbs==1)
{strcpy(p.sexe,"femelle");
cbs==0;}


chercher_crit(p);

fenetre_rechsexe=lookup_widget(objet,"recherche_sexe");

gtk_widget_destroy(fenetre_rechsexe);
fenetre_afficher_recherche=lookup_widget(objet,"affichage_recherche");
fenetre_afficher_recherche=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher_recherche);


treeview3= lookup_widget(fenetre_afficher_recherche,"treeview3");
afficher_rech(treeview3);
}


void
on_checkbutton1_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{

}


void
on_checkbutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechsant;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_rechsant=lookup_widget(objet,"Recherche_sante");

gtk_widget_destroy(fenetre_rechsant);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}


void
on_button19_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
troupeaux p;
GtkWidget *fenetre_rechsante;
GtkWidget *fenetre_afficher_recherche;
GtkWidget *treeview3;
GtkWidget *input1;





fenetre_rechsante=lookup_widget(objet,"Recherche_sante");
if(cbo==0)
{
strcpy(p.sante,"OK");
cbo==0;}
else if(cbo==1)
{strcpy(p.sante,"NOT_OK");
cbo==0;}


chercher_crit(p);

fenetre_rechsante=lookup_widget(objet,"Recherche_sante");

gtk_widget_destroy(fenetre_rechsante);
fenetre_afficher_recherche=lookup_widget(objet,"affichage_recherche");
fenetre_afficher_recherche=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher_recherche);


treeview3= lookup_widget(fenetre_afficher_recherche,"treeview3");
afficher_rech(treeview3);
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{cbo=1;}
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{cbo=0;}
}


void
on_modifier_show                       (GtkWidget       *widget,
                                        gpointer         user_data)
{

}


void
on_button21_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input;
GtkWidget *input3;
GtkWidget *input5;
GtkWidget *input4;
GtkWidget *rr;

int j,m,a;
char yy[100];

strcpy(yy,"youssef");
input3=lookup_widget(objet,"spinbutton1");
input4=lookup_widget(objet,"spinbutton2");
input5=lookup_widget(objet,"spinbutton3");
input1=lookup_widget(objet,"combobox2");
input=lookup_widget(objet,"entry_matricule_modif");
rr=lookup_widget(objet,"radiobutton9");
gtk_combo_box_text_append_text(GTK_COMBO_BOX(input1),inter.espece);
gtk_entry_set_text(GTK_ENTRY(input),inter.matricule);
gtk_entry_set_text(GTK_ENTRY(input1),(yy));
j=atoi(inter.jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input3),j);
m=atoi(inter.mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input4),m);
a=atoi(inter.annee);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input5),a);


}





void
on_button14y_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechmat;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_rechmat=lookup_widget(objet,"Recherche_matricule");

gtk_widget_destroy(fenetre_rechmat);
fenetre_afficher=lookup_widget(objet,"affichage");
fenetre_afficher=create_affichage();
gtk_widget_show(fenetre_afficher);


treeview1= lookup_widget(fenetre_afficher,"treeview1");
afficher_troupeaux(treeview1);
}


void
on_button24_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *input3;



input3=lookup_widget(objet,"combobox3");
combobox(input3);

}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{cbs=0;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{cbs=1;}
}


void
on_button22_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_aff;
GtkWidget *fenetre_modif;



fenetre_aff=lookup_widget(objet,"affichage_recherche");
gtk_widget_destroy(fenetre_aff);
fenetre_modif=lookup_widget(objet,"modifieraff");
fenetre_modif= create_modifieraff ();
gtk_widget_show(fenetre_modif);
}


void
on_button23_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_aff;
GtkWidget *fenetre_supp;





fenetre_aff=lookup_widget(objet,"affichage_recherche");
gtk_widget_destroy(fenetre_aff);
fenetre_supp=lookup_widget(objet,"supprimeaff");
fenetre_supp= create_supprimeaff ();
gtk_widget_show(fenetre_supp);

}


void
on_button26_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *sortie;

supprimeraff(inter);
supprimer(inter);
sortie=lookup_widget(objet,"label103");
gtk_label_set_text(GTK_LABEL(sortie),"l élement a été supprimé");
}


void
on_button25_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_supp;
GtkWidget *fenetre_afficher_recherche;
GtkWidget *treeview3;


fenetre_supp=lookup_widget(objet,"supprimeaff");

gtk_widget_destroy(fenetre_supp);
fenetre_afficher_recherche=lookup_widget(objet,"affichage_recherche");
fenetre_afficher_recherche=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher_recherche);


treeview3= lookup_widget(fenetre_afficher_recherche,"treeview3");
afficher_rech(treeview3);
}


void
on_button28_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
troupeaux p;
GtkWidget *fenetre_modif;
GtkWidget *input;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
char j[50];
char m[50];
char a[50];
int jour,mois,annee;



fenetre_modif=lookup_widget(objet,"modifieraff");
input=lookup_widget(objet,"matriculerech");
input1=lookup_widget(objet,"combobox5");
input2=lookup_widget(objet,"spinbuttonj");
input3=lookup_widget(objet,"spinbuttonm");
input4=lookup_widget(objet,"spinbuttona");
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
sprintf(j,"%d",jour);
sprintf(m,"%d",mois);
sprintf(a,"%d",annee);
strcpy(p.matricule,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(p.espece,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(p.jour,j);
strcpy(p.mois,m);
strcpy(p.annee,a);

 if(rs==0)
{strcpy(p.sexe,"male");
rs=0; }
else if(rs==1)
{strcpy(p.sexe,"femelle");
rs=0; }

 if(ro==0)
{strcpy(p.sante,"OK"); 
ro=0;}
else if(ro==1)
{strcpy(p.sante,"NOT_OK");
ro=0; }



modifier(p,inter);
modifierrech(p,inter);

GtkWidget *fenetre_modifier;
GtkWidget *fenetre_afficher;
GtkWidget *treeview3;


fenetre_modifier=lookup_widget(objet,"modifieraff");

gtk_widget_destroy(fenetre_modif);
fenetre_afficher=lookup_widget(objet,"affichage_recherche");
fenetre_afficher=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher);


treeview3= lookup_widget(fenetre_afficher,"treeview3");
afficher_rech(treeview3);

}


void
on_button27_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modif;
GtkWidget *fenetre_afficher;
GtkWidget *treeview3;


fenetre_modif=lookup_widget(objet,"modifieraff");

gtk_widget_destroy(fenetre_modif);
fenetre_afficher=lookup_widget(objet,"affichage_recherche");
fenetre_afficher=create_affichage_recherche ();
gtk_widget_show(fenetre_afficher);


treeview3= lookup_widget(fenetre_afficher,"treeview3");
afficher_rech(treeview3);
}


void
on_button29_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input;
GtkWidget *input3;
GtkWidget *input5;
GtkWidget *input4;


int j,m,a;



input3=lookup_widget(objet,"spinbuttonj");
input4=lookup_widget(objet,"spinbuttonm");
input5=lookup_widget(objet,"spinbuttona");
input1=lookup_widget(objet,"combobox5");
input=lookup_widget(objet,"matriculerech");
gtk_combo_box_text_append_text(GTK_COMBO_BOX(input1),inter.espece);
gtk_entry_set_text(GTK_ENTRY(input),inter.matricule);

j=atoi(inter.jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input3),j);
m=atoi(inter.mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input4),m);
a=atoi(inter.annee);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input5),a);
}


void
on_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{rs=1;}
}


void
on_radiobutton14_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ro=1;}
}


void
on_radiobutton16_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{rs=0;}
}


void
on_radiobutton17_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ro=0;}
}


//////////////////////////////////youssef//////////////////////////////////////////////////

//////////////////////////////////Emna//////////////////////////////////////////////////


void
on_button1e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window2=create_window2() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window2);
}


void
on_button2e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window3;
window3=create_window3() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window3);
}


void
on_button3e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4;
window4=create_window4() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window4);
}


void
on_button4e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window5;
window5=create_window5() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window5);
}


void
on_button5e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview1;
window1=lookup_widget(objet_graphique,"window1");
treeview1=lookup_widget(window1,"treeview1");
afficher(treeview1);
}


void
on_button7_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *output,*input1 , *input2, *input3, *input4, *input5 ;
GtkWidget *window2;
int x;
plante p;
window2=create_window2();
input2=lookup_widget(objet_graphique,"entry2"); 
input3=lookup_widget(objet_graphique,"entry3"); 
input4=lookup_widget(objet_graphique,"entry4"); 
input5=lookup_widget(objet_graphique,"entry5"); 
output=lookup_widget(objet_graphique,"label16"); 
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(p.dosage,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.plantation,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.recolte,gtk_entry_get_text(GTK_ENTRY(input5)));
ajout(p);
/*if ((strcmp(p.nom,"")==0)||(strcmp(p.plantation,"")==0)||(strcmp(p.recolte,"")==0)||(strcmp(p.dosage,"")==0))
{
 gtk_label_set_text(GTK_LABEL(output),"remplir tous les champs!");
}
else 
{
ajout(p);
gtk_label_set_text(GTK_LABEL(output),"l'equipement est ajouté avec succés");}*/ 

}


void
on_button9_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window1=create_window1() ;
window2=lookup_widget(objet_graphique,"window2");
gtk_widget_hide(window2);
gtk_widget_show (window1);
}


void
on_button11e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output, *input1 , *input2, *input3, *input4, *input5;
GtkWidget *window3;
plante p;
window3=create_window3();
input2=lookup_widget(objet_graphique,"entry7"); 
input3=lookup_widget(objet_graphique,"entry8"); 
input4=lookup_widget(objet_graphique,"entry9"); 
input5=lookup_widget(objet_graphique,"entry10"); 
output=lookup_widget(objet_graphique,"label15");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(p.recolte,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.plantation,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.dosage,gtk_entry_get_text(GTK_ENTRY(input5)));
modifiere(p);
gtk_label_set_text(GTK_LABEL(output),"plante est modifié avec succés");
}


void
on_button10e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window3;
window1=create_window1() ;
window3=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window3);
gtk_widget_show (window1);
}


void
on_button13e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
GtkWidget *window4;
window4=create_window4();
char n[20];
int x;
input1=lookup_widget(objet_graphique,"entry13");
strcpy(n,gtk_entry_get_text(GTK_ENTRY(input1))); 
output=lookup_widget(objet_graphique,"label20");
x=rech(n);
if(x==1)
{
supp(n);
gtk_label_set_text(GTK_LABEL(output),"plante est supprimé avec succés");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"plante inexistant");
}
}


void
on_button12e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4;
window1=create_window1() ;
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
gtk_widget_show (window1);
}


void
on_button15e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
GtkWidget *window5;
window5=create_window5();
char n[20];
int x;
plante p;
input1=lookup_widget(objet_graphique,"entry12");
strcpy(n,gtk_entry_get_text(GTK_ENTRY(input1))); 
output=lookup_widget(objet_graphique,"label24");
x=rech(n);

if(x==1)
{

gtk_label_set_text(GTK_LABEL(output),"plante existe");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"plante inexistant");
}
}


void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window5;
window1=create_window1() ;
window5=lookup_widget(objet_graphique,"window5");
gtk_widget_hide(window5);
gtk_widget_show (window1);
}


void
on_button60_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_seche_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
window6 = create_window6();
gtk_widget_show (window6);
gtk_widget_hide (window1);
}


void
on_button_chercher_annee_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[40];
char labelAnnee[10];
int aa;
GtkWidget *radiobutt1;
GtkWidget *radiobutt2;
radiobutt1=lookup_widget(window6,"radiobutton1");
radiobutt2=lookup_widget(window6,"radiobutton2");
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radiobutt1) )){
strcpy(fich,"humidite.txt");
}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radiobutt2) )){
strcpy(fich,"temperature.txt");
}
aa = trouver_annee_plus_seche(fich);
sprintf(labelAnnee,"%d",aa);
gtk_label_set_text(GTK_LABEL( lookup_widget(window6,"label32") ),labelAnnee);




}


void
on_button_window6_window1_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window6);
}


void
on_remplirPlante_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(objet_graphique,"window3");
plante p;
plante p1;
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY( lookup_widget(window3,"entry7") )));
p1 = trouver_plante(p.nom);
printf("%s\n",p1.recolte);
if(strcmp(p1.recolte,"notExists")!=0){
	gtk_entry_set_text(GTK_ENTRY(lookup_widget(window3,"entry8")),p1.recolte);	
	gtk_entry_set_text(GTK_ENTRY(lookup_widget(window3,"entry9")),p1.plantation);	
	gtk_entry_set_text(GTK_ENTRY(lookup_widget(window3,"entry10")),p1.dosage);	

}

}


//////////////////////////////////Emna//////////////////////////////////////////////////


void
on_dec_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_authentification();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Alaa_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_gestion_capteur();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Tarek_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_gestion_des_equipements();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Youssef_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_affichage();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Emna_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_window1();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Mariem_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_vente();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);        
}


void
on_khawla_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
t7al=create_afficher_ouvriers();
gtk_widget_show (t7al);
tsakker=lookup_widget(objet,"menu");
gtk_widget_destroy (tsakker);
}


void
on_Deconnexion_tarek_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
GtkWidget *ouvrir ,*fermer;
ouvrir=create_menu();
gtk_widget_show (ouvrir);

tsakker=lookup_widget(objet,"gestion_des_equipements");
gtk_widget_destroy (tsakker);
}


void
on_button84_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *t7al ,*tsakker;
GtkWidget *ouvrir ,*fermer;
ouvrir=create_menu();
gtk_widget_show (ouvrir);

tsakker=lookup_widget(objet,"window1");
gtk_widget_destroy (tsakker);
}

///////////////////////////mariem//////////////////////////////////

char reference1[70];
 char nom1[70];
 char prenom1[70];
 char genre1[70];
 char adresse1[70];
 char telephone1[70];
 char email1[70];
 char date1[70];
void
on_treeview1m_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
client c;
GtkTreeIter iter;
gchar* reference;
gchar* nom;
gchar* prenom;
gchar* genre;
gchar* adresse;
gchar* telephone;
gchar* email;
gchar* date;

GtkTreeModel *model=gtk_tree_view_get_model(treeview);
gtk_tree_model_get_iter(model,&iter,path);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&reference,1,&nom,2,&prenom,3,&genre,4,&adresse,5,&telephone,6,&email,7,&date,-1);
strcpy(reference1,reference);
strcpy(nom1,nom);
strcpy(prenom1,prenom);
strcpy(genre1,genre);
strcpy(adresse1,adresse);
strcpy(telephone1,telephone);
strcpy(email1,email);
strcpy(date1,date);///////
}
}


void
on_ajoutermar_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"client");
	gtk_widget_destroy(fermer);
	ouvrir=create_ajout();
	gtk_widget_show(ouvrir);

}


void
on_actualisermar_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1");
afficherma(treeview1);
}


void
on_supprimermar_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"client");
	gtk_widget_destroy(fermer);
	ouvrir=create_sup1();
	gtk_widget_show(ouvrir);
}


void
on_modifiermar_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
int x;
client c;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*ref,*treeview1;
GtkWidget *j,*m,*a;

	GtkWidget *ouvrir,*fermer ;

	ouvrir=create_modif();
	gtk_widget_show(ouvrir);

        treeview1=lookup_widget(objet,"treeview1");

 	fermer=lookup_widget(objet,"client");
	gtk_widget_destroy(fermer);

ref=lookup_widget(ouvrir,"vide");
input1=lookup_widget(ouvrir,"nomm");
input2=lookup_widget(ouvrir,"prenomm");
input3=lookup_widget(ouvrir,"combomodif");//combobox
input4=lookup_widget(ouvrir,"madresse");
input5=lookup_widget(ouvrir,"mtelephone");
input6=lookup_widget(ouvrir,"memail");//

j= lookup_widget(ouvrir,"mjour");
m= lookup_widget(ouvrir,"mmois");
a= lookup_widget(ouvrir,"mannee");

gtk_entry_set_text(GTK_ENTRY(input1),nom1);
gtk_entry_set_text(GTK_ENTRY(input2),prenom1);
gtk_entry_set_text(GTK_ENTRY(input4),adresse1);
gtk_entry_set_text(GTK_ENTRY(input5),telephone1);
gtk_entry_set_text(GTK_ENTRY(input6),email1);


if(strcmp(genre1,"Homme")==0) x=0;
if(strcmp(genre1,"Femme")==0) x=1;
gtk_combo_box_set_active(GTK_COMBO_BOX(input3),x);//

char cj[70],cm[70],ca[70];
cj[0]=date1[0];
cj[1]=date1[1];

cm[0]=date1[3];
cm[1]=date1[4];

ca[0]=date1[6];
ca[1]=date1[7];
ca[2]=date1[8];
ca[3]=date1[9];

int jr=atoi(cj);
int mr=atoi(cm);
int ar=atoi(ca);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(j),jr);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(m),mr);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(a),ar);

gtk_label_set_text(GTK_LABEL(ref),reference1);
}


void
on_recherchemar_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *search,*input;
search=lookup_widget(objet,"referencer");
strcpy(reference1,gtk_entry_get_text(GTK_ENTRY(search)));

GtkWidget *treeview1 ,*ouvrir ;
ouvrir=lookup_widget(objet,"client");
gtk_widget_destroy(ouvrir);
ouvrir=create_client();
gtk_widget_show(ouvrir);
treeview1=lookup_widget(ouvrir,"treeview1");
afficher_rechma(treeview1,reference1);

char msg[]="recherche terminée avec succés";
input=lookup_widget(objet,"msgrech");
gtk_label_set_text(GTK_LABEL(input),msg);
}


void
on_deconnexionmar_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"client");
	gtk_widget_destroy(fermer);
	ouvrir=create_menu();
	gtk_widget_show(ouvrir);
}


void
on_button3gh_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *j,*m,*a;
char jour[70],mois[70],annee[70];
char date_jour[70];

input1=lookup_widget(objet,"reference");
input2=lookup_widget(objet,"nom");
input3=lookup_widget(objet,"prenom");
input5=lookup_widget(objet,"combogenre");//combobox
input4=lookup_widget(objet,"adresse");
input6=lookup_widget(objet,"telephone");
input7=lookup_widget(objet,"email");

	j= lookup_widget(objet,"jour");
	m= lookup_widget(objet,"spinbutton2");
	a= lookup_widget(objet,"annee");

strcpy(c.reference,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.genre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));//combobox
strcpy(c.telephone,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(input7)));

c.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));//spin button
c.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));
sprintf(jour,"%d",c.jour);
sprintf(mois,"%d",c.mois);
sprintf(annee,"%d",c.annee);

char cj[70]="0";
char cm[70]="0";

if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);

if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);

strcpy(date_jour,cj);
strcat(date_jour,"/");
strcat(date_jour,cm);
strcat(date_jour,"/");
strcat(date_jour,annee);  
               
strcpy(c.date,date_jour);


ajouterma(c);

GtkWidget *ouvrir,*treeview1,*fermer;

fermer=lookup_widget (objet,"ajout");
gtk_widget_destroy(fermer);

ouvrir=create_client();
gtk_widget_show(ouvrir);
treeview1=lookup_widget(ouvrir,"treeview1");
afficherma(treeview1);
}


void
on_retourgh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer;

fermer=lookup_widget (objet,"ajout");
gtk_widget_destroy(fermer);

ouvrir=create_client();
gtk_widget_show(ouvrir);
}


void
on_retourmar_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ouvrir,*fermer;

fermer=lookup_widget (objet,"modif");
gtk_widget_destroy(fermer);

ouvrir=create_client();
gtk_widget_show(ouvrir);
}


void
on_validermar_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*ref;
GtkWidget *j,*m,*a;
char jour[70],mois[70],annee[70];
char date_jour[70];

ref=lookup_widget(objet,"vide");
input1=lookup_widget(objet,"nomm");
input2=lookup_widget(objet,"prenomm");
input3=lookup_widget(objet,"combomodif");//combobox
input4=lookup_widget(objet,"madresse");
input5=lookup_widget(objet,"mtelephone");
input6=lookup_widget(objet,"memail");//
 GtkWidget *msg=lookup_widget(objet,"message");

j= lookup_widget(objet,"mjour");
m= lookup_widget(objet,"mmois");
a= lookup_widget(objet,"mannee");

strcpy(c.reference,gtk_label_get_text(GTK_ENTRY(ref)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.genre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));//combobox
strcpy(c.telephone,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(input6)));

c.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));//spin button
c.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

sprintf(jour,"%d",c.jour);
sprintf(mois,"%d",c.mois);
sprintf(annee,"%d",c.annee);


char cj[70]="0";
char cm[70]="0";

if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);

if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);

strcpy(date_jour,cj);
strcat(date_jour,"/");
strcat(date_jour,cm);
strcat(date_jour,"/");
strcat(date_jour,annee);  
               
strcpy(c.date,date_jour);

supprimerma(c);
ajouterma(c);

gtk_label_set_text(GTK_LABEL(msg),"modification réussite!");
}


void
on_nonc_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"sup1");
	gtk_widget_destroy(fermer);
	ouvrir=create_client();
	gtk_widget_show(ouvrir);
}


void
on_ouic_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	client c;
	strcpy(c.reference,reference1);
	supprimerma(c);

char msg[]="suppression terminée avec succés";
GtkWidget *input=lookup_widget(objet,"signemsg");
gtk_label_set_text(GTK_LABEL(input),msg);
}


void
on_retourma_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"sup1");
	gtk_widget_destroy(fermer);
	ouvrir=create_client();
	gtk_widget_show(ouvrir);
}


///////////////////////////////vente//////////////////////

char reference1[70];
char categorie1[70];
 char type1[70];
 char quantite1[70];
char date1[70];

void
on_treeview1gh_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{
produit p;
GtkTreeIter iter;
gchar* reference;
gchar* categorie;
gchar* type;
gchar* quantite;
gchar* date;


GtkTreeModel *model=gtk_tree_view_get_model(treeview);
gtk_tree_model_get_iter(model,&iter,path);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&reference,1,&categorie,2,&type,3,&quantite,4,&date,-1);
strcpy(reference1,reference);
strcpy(categorie1,categorie);
strcpy(type1,type);
strcpy(quantite1,quantite);
strcpy(date1,date);/////
}
}

void
on_supprimerv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"vente");
	gtk_widget_destroy(fermer);
	ouvrir=create_sup2();
	gtk_widget_show(ouvrir);
}

void
on_ajoutv_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
   	GtkWidget *afficher_produit,*ajout_produit ;
	ajout_produit=create_ajoutv();
	gtk_widget_show(ajout_produit);
 	afficher_produit=lookup_widget(objet,"vente");
	gtk_widget_destroy(afficher_produit);

}

void
on_validerv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{


produit p;
GtkWidget *input1,*input2,*input3,*input4;
GtkWidget *j,*m,*a;
char jour[70],mois[70],annee[70];
char date_jour[70];

input1=lookup_widget(objet,"referencev");
input2=lookup_widget(objet,"combocategorie");//combobox
input3=lookup_widget(objet,"combotype");//combobox
input4=lookup_widget(objet,"quantite");

	j= lookup_widget(objet,"joura");
	m= lookup_widget(objet,"moisa");
	a= lookup_widget(objet,"anneea");

strcpy(p.reference,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));//combobox
strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));//combobox
strcpy(p.quantite,gtk_entry_get_text(GTK_ENTRY(input4)));


p.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));//spin button
p.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
p.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

sprintf(jour,"%d",p.jour);
sprintf(mois,"%d",p.mois);
sprintf(annee,"%d",p.annee);

char cj[70]="0";
char cm[70]="0";

if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);

if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);

strcpy(date_jour,cj);
strcat(date_jour,"/");
strcat(date_jour,cm);
strcat(date_jour,"/");
strcat(date_jour,annee);  
               
strcpy(p.date,date_jour);


ajouter_m(p);

GtkWidget *ouvrir,*treeview1,*fermer;

fermer=lookup_widget (objet,"ajoutv");
gtk_widget_destroy(fermer);

ouvrir=create_vente();
gtk_widget_show(ouvrir);
treeview1=lookup_widget(ouvrir,"treeview1gh");
afficher_m(treeview1);

}

void
on_actualiserv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1gh");
afficher_m(treeview1);
}


void
on_recherchev_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
produit p;
GtkWidget *search,*input;
search=lookup_widget(objet,"entryrecherche");
strcpy(reference1,gtk_entry_get_text(GTK_ENTRY(search)));

GtkWidget *treeview1 ,*ouvrir ;
ouvrir=lookup_widget(objet,"vente");
gtk_widget_destroy(ouvrir);
ouvrir=create_vente();
gtk_widget_show(ouvrir);
treeview1=lookup_widget(ouvrir,"treeview1gh");
afficher_recherche(treeview1,reference1);

char msg[]="Recherche terminée avec succés!!";
input=lookup_widget(ouvrir,"label50");
gtk_label_set_text(GTK_LABEL(input),msg);
}


void
on_modifierv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
int xm,ym;
produit p;

GtkWidget *input1,*input2,*input3,*input4,*treeview1;
GtkWidget *j,*m,*a;

GtkWidget *ouvrir,*fermer ;

	ouvrir=create_modifv();
	gtk_widget_show(ouvrir);

        treeview1=lookup_widget(objet,"treeview1gh");

 	fermer=lookup_widget(objet,"vente");
	gtk_widget_destroy(fermer);


input1=lookup_widget(ouvrir,"empty");
input2=lookup_widget(ouvrir,"combocategorie1");//combobox
input3=lookup_widget(ouvrir,"combotype1");//combobox
input4=lookup_widget(ouvrir,"entry1");


	j= lookup_widget(ouvrir,"jourv");
	m= lookup_widget(ouvrir,"moisv");
	a= lookup_widget(ouvrir,"anneev");

gtk_entry_set_text(GTK_ENTRY(input4),quantite1);


if(strcmp(categorie1,"Fruits")==0) xm=0;
if(strcmp(categorie1,"Legumes")==0) xm=1;
if(strcmp(categorie1,"Cremerie")==0) xm=2;
if(strcmp(categorie1,"Animalerie")==0) xm=3;
gtk_combo_box_set_active(GTK_COMBO_BOX(input2),xm);



if(strcmp(type1,"Orange")==0) ym=0;
if(strcmp(type1,"Pomme")==0) ym=1;
if(strcmp(type1,"Fraise")==0) ym=2;
if(strcmp(type1,"Tomate")==0) ym=3;
if(strcmp(type1,"Laittue")==0) ym=4;
if(strcmp(type1,"Fromage")==0) ym=5;
if(strcmp(type1,"Beurre")==0) ym=6;
if(strcmp(type1,"Brebie")==0) ym=7;
if(strcmp(type1,"Agneau")==0) ym=8;


gtk_combo_box_set_active(GTK_COMBO_BOX(input3),ym);//

char cj[70],cm[70],ca[70];
cj[0]=date1[0];
cj[1]=date1[1];

cm[0]=date1[3];
cm[1]=date1[4];

ca[0]=date1[6];
ca[1]=date1[7];
ca[2]=date1[8];
ca[3]=date1[9];

int jr=atoi(cj);
int mr=atoi(cm);
int ar=atoi(ca);


gtk_spin_button_set_value(GTK_SPIN_BUTTON(j),jr);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(m),mr);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(a),ar);

gtk_label_set_text(GTK_LABEL(input1),reference1);
}

void
on_validervente_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
produit p;
GtkWidget *input1,*input2,*input3,*ref;
GtkWidget *j,*m,*a;
char jour[70],mois[70],annee[70];
char date_jour[70];

ref=lookup_widget(objet,"empty");
input1=lookup_widget(objet,"combocategorie1");//combobox
input2=lookup_widget(objet,"combotype1");//combobox
input3=lookup_widget(objet,"entry1");//
 GtkWidget *msg=lookup_widget(objet,"message1");

j= lookup_widget(objet,"jourv");
m= lookup_widget(objet,"moisv");
a= lookup_widget(objet,"anneev");

strcpy(p.reference,gtk_label_get_text(GTK_ENTRY(ref)));
strcpy(p.categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));//combobox
strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));//combobox
strcpy(p.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));

p.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));//spin button
p.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
p.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

sprintf(jour,"%d",p.jour);
sprintf(mois,"%d",p.mois);
sprintf(annee,"%d",p.annee);


char cj[70]="0";
char cm[70]="0";

if(strlen(jour)==1)
strcat(cj,jour);
else strcpy(cj,jour);

if(strlen(mois)==1)
strcat(cm,mois);
else strcpy(cm,mois);

strcpy(date_jour,cj);
strcat(date_jour,"/");
strcat(date_jour,cm);
strcat(date_jour,"/");
strcat(date_jour,annee);  
               
strcpy(p.date,date_jour);

supprimer_m(p);
ajouter_m(p);
gtk_label_set_text(GTK_LABEL(msg),"modification réussite!");
}


void
on_retourv_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *treeview,*afficher_produit,*ajouter_produit;
	
	ajouter_produit=lookup_widget(objet,"modifv");
	gtk_widget_destroy(ajouter_produit);	

	afficher_produit=create_vente();
	gtk_widget_show(afficher_produit);

	treeview=lookup_widget(afficher_produit,"treeview1gh");

	afficher_m(treeview);

}
void
on_nonv_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"sup2");
	gtk_widget_destroy(fermer);
	ouvrir=create_vente();
	gtk_widget_show(ouvrir);
	GtkWidget *treeview1;
	treeview1=lookup_widget(objet,"treeview1gh");
	afficher_m(treeview1);

}

void
on_ouiv_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	produit p;
	strcpy(p.reference,reference1);
	supprimer_m(p);

char msg[]="suppression terminée avec succés!";
GtkWidget *input=lookup_widget(objet,"supv");
gtk_label_set_text(GTK_LABEL(input),msg);
}

void
on_retourmg_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"sup2");
	gtk_widget_destroy(fermer);
	ouvrir=create_vente();
	gtk_widget_show(ouvrir);
	GtkWidget *treeview1;
	treeview1=lookup_widget(objet,"treeview1gh");
	afficher_m(treeview1);
}

void
on_gestionclient_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"vente");
	gtk_widget_destroy(fermer);
	ouvrir=create_client();
	gtk_widget_show(ouvrir);
}




void
on_button110ghr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ouvrir,*fermer ;
 	fermer=lookup_widget(objet,"vente");
	gtk_widget_destroy(fermer);
	ouvrir=create_menu();
	gtk_widget_show(ouvrir);
}

