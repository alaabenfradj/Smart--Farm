typedef struct{
char reference[70];
char nom[70];
char prenom[70];
char genre [70];
char adresse[70];
char telephone[70];
char date[70];
char email[70];
int jour;
int mois;
int annee;
}client;

void afficherma(GtkWidget *liste);
void ajouterma( client c);
void supprimerma(client c);
void afficher_rechma(GtkWidget *liste,char*ref);
