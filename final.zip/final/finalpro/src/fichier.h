#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct 
{
char nom[20];
char plantation[20];
char dosage[20];
char recolte[20];
}plante;

int ajout(plante p);
int rech(char n[20]);
void supp(char n[20]);
void modifiere(plante p1);
void afficher(GtkWidget *liste);
plante trouver_plante(char*nom) ;


