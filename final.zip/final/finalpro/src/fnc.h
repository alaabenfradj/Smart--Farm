typedef struct
{
char produit[20];
char disponibilite[20];
int prix;
char promotion[10];
}cathalogue;

//affichage du cathalogue
void cathaloque_des_produits(cathalogue *c,int n);
//ajoter un produit
void ajout_produit(cathalogue *at , int n);
//supprimer un prouduit
void supprimer_produit(cathalogue *s , int n);

