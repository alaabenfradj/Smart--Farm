#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
void modifiere (plante p1)
{

FILE *f;
FILE *f1;
plante p;
f=fopen("planning_plante.txt","r");
f1=fopen("planning_plante1.txt","w");
while(fscanf(f," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte)!=EOF)
 {if(strcmp(p1.nom,p.nom)!=0)      
fprintf(f1," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte);
}
fprintf(f1," %s %s %s %s \n",p1.nom,p1.plantation,p1.dosage,p1.recolte);
fclose(f);
fclose(f1);
remove("planning_plante.txt");
rename("planning_plante1.txt","planning_plante.txt");
}




plante trouver_plante(char*nom) {

FILE*f=NULL;
plante p ;
plante p1 ;
int b=0;
f=fopen("planning_plante.txt","r");
while(fscanf(f," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte)!=EOF){
if (strcmp(p.nom,nom)==0)
{
p1=p;
b=1;
}

}
fclose(f);
if(b==0){
strcpy(p1.recolte,"notExists");
}

return  p1;
}
