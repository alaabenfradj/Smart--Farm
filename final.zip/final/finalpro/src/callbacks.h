#include <gtk/gtk.h>


void
on_Modifiergtarek_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retourstarek_clicked                     (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerstarek_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonEnregistrer1_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour2_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonEnregistrer2_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour6_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonEnregistrer6_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour3_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonEnregister3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour4_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ButtonEnregistrer4_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonEnregistrer5_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetour5_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajoutergtarek_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_afficherg_clicked                   (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_Modifierg_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimergtarek_clicked                  (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_retouratarek_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouteratarek_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_retourmo_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_enregistrermo_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_retourliste_clicked                 (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_cherchergtarek_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonokp_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonpa_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_D__ffectueux_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1tarek_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);







void
on_ajoutery_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_modifiergy_clicked                   (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_retourgy_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_supprimergy_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retouray_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validery_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_vache2_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_poule2_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_coq2_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_taureau2_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_mouton2_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_lapin2_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_dindon2_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_ch__vre2_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cheval2_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_canard2_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_ane2_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_vache1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_poule1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_coq1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_taureau1_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_mouton1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_lapin1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_dindon1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_ch__vre1_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cheval1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_canard1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_ane1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_modifiermy_clicked                   (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retourmy_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);




void
on_Supprimer_produit_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_inscription_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_option_specialite_ajout_changed     (GtkOptionMenu   *optionmenu,
                                        gpointer         user_data);

void
on_jour_changed                        (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_mois_changed                        (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_annee_changed                       (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_male_group_changed                  (GtkRadioButton  *radiobutton,
                                        gpointer         user_data);

void
on_femelle_group_changed               (GtkRadioButton  *radiobutton,
                                        gpointer         user_data);

void
on_treeview1alaa_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retoury_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);


void
on_button4_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);



void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton13_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checherch_clicked                   (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_rech_mat_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_modifier_show                       (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_button14y_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_radiobutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton14_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton16_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton17_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_button2tarek_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);






void
on_modifiergk_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimergk_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnexiong_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_t_absence_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2k_row_activated             (GtkWidget     *objet,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourak_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validerk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmk_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifiermk_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_non_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_oui_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_male_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femelle_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_id_g_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_male1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femelle1_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour_supp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_abs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_abs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_abs_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_abs_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_abs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aj_abs_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_yes_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_no_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_yes1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_no1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_absence_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_abs_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nonsup_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ouisup_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview3k_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_back_ajout_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_back_modif_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_back_supp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiser_abs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_taux_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_taux_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_inscrire_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_connecter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retoursauthentifier_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimerg_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierg_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_retourg_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_butt_cherch_gest_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton2alaa_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1alaa_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retoura_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_capteur_show              (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_annuler_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ok_supprimer_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_capteur_show               (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok_modifier_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_alarmants_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_val_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ok_ajout_valeur_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_valeur_show                   (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_retour_alarmant_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_alarmants_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_val_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refrech_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_diff_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_diff_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_gestion_capteur_show                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_cheralarm_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_cherHum_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_plusalarm_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiserk_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_def_marque_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);





GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window4;
GtkWidget *window5;
GtkWidget *window6;
typedef struct temperature temperature;
struct temperature{
char idCapteur[20];
int jj;
int mm;
int aa;
float valeur;
};
typedef struct tabAnneeMoy tabAnneeMoy;
struct tabAnneeMoy{
int aa;
float moy;
};

void
on_button1e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button2e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button3e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button4e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button5e_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button11e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);




void
on_dec_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Alaa_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Tarek_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Youssef_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Emna_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Mariem_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_khawla_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button10e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button13e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button12e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button15e_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button60_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button_seche_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_annee_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_window6_window1_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_remplirPlante_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_Deconnexion_tarek_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button84_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_treeview1m_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajoutermar_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualisermar_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimermar_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifiermar_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_recherchemar_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnexionmar_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3gh_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourgh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmar_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validermar_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nonc_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ouic_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourma_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_treeview1gh_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimerv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajoutv_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_validerv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_actualiserv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_recherchev_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validervente_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_retourv_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nonv_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ouiv_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmg_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_gestionclient_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button110ghr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
