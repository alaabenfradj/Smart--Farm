#include<stdio.h>
#include<stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include "vente.h"

enum
{
 EREFERENCE,
 ECATEGORIE,
 ETYPE,
 EQUANTITE,
 EDATE,
 COLUMNS
};

void ajouter_m(produit p)
{
FILE *f=NULL;
f = fopen("produits.txt", "a+" );
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s \n",p.reference,p.categorie,p.type,p.quantite,p.date);
fclose(f);
}
else
printf("impossible d'ouvrir le fichier");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void afficher_m(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

 char reference[70];
 char categorie[70];
 char type[70];
 char quantite[70];
 char date[70];

 store=NULL;
 FILE *f;
 store=gtk_tree_view_get_model(liste);
if (store==NULL)
  {
  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("REFERENCE",renderer,"text",EREFERENCE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("CATEGORIE",renderer,"text",ECATEGORIE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("TYPE",renderer,"text",ETYPE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("QUANTITE",renderer,"text",EQUANTITE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("DATE",renderer,"text",EDATE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("produits.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("produits.txt","a+");
 while( fscanf(f,"%s %s %s %s %s\n",reference,categorie,type,quantite,date)!=EOF)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EREFERENCE,reference,ECATEGORIE,categorie,ETYPE,type,EQUANTITE,quantite,EDATE,date,-1); //mise à jour des données
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void supprimer_m(produit p)
{
FILE*f=NULL;
FILE*ftemp=NULL;
 produit p1;
f= fopen("produits.txt", "r");

 ftemp = fopen("produits_temp.txt", "a+");
 if (f!=NULL)

{
while(fscanf(f,"%s %s %s %s %s\n",p1.reference,p1.categorie,p1.type,p1.quantite,p1.date)!=EOF)
{
if(strcmp(p1.reference,p.reference)!=0)
fprintf(ftemp,"%s %s %s %s %s\n",p1.reference,p1.categorie,p1.type,p1.quantite,p1.date);
}
}
fclose(f);
fclose(ftemp);
remove("produits.txt");
    rename("produits_temp.txt","produits.txt");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void afficher_recherche(GtkWidget *liste,char*ref)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

 char reference[70];
 char categorie[70];
 char type[70];
 char quantite[70];
 char date[70];

 store=NULL;
 FILE *f;
 store=gtk_tree_view_get_model(liste);
if (store==NULL)
  {
  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("REFERENCE",renderer,"text",EREFERENCE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("CATEGORIE",renderer,"text",ECATEGORIE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("TYPE",renderer,"text",ETYPE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("QUANTITE",renderer,"text",EQUANTITE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

  renderer=gtk_cell_renderer_text_new ();
  column= gtk_tree_view_column_new_with_attributes("DATE",renderer,"text",EDATE,NULL);
  gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("produits.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("produits.txt","a+");
 while( fscanf(f,"%s %s %s %s %s\n",reference,categorie,type,quantite,date)!=EOF)
	{
	if (strcmp(reference,ref)==0)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EREFERENCE,reference,ECATEGORIE,categorie,ETYPE,type,EQUANTITE,quantite,EDATE,date,-1); //mise à jour des données
	}
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	}
	

