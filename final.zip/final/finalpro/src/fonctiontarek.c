#ifdef HAVE_CONFIG_H
# include <config.h>
#endif


#include <gtk/gtk.h>
#include <stdio.h>
#include "equip.h"
#include <string.h>
#include <stdlib.h>


void ajouter_equipement(equipement e)
{

FILE *f;
equipement ee;

f=fopen("equipement.txt","a+");

 if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s \n",e.Ref,e.designation,e.marque,e.etat,e.date_achat);
fclose(f);	
}
}
/*
void modifier_equipement(char Ref,equipement e1)
{

equipement e;
FILE *f;
FILE *fa;
f=fopen("equipement.txt","r");
fa=fopen("equipement1.txt","w");
while(fscanf(f,"%s %s %s %s %s\n",e.Ref,e.designation,e.marque,e.etat,e.date_achat)!=EOF)
 {if(Ref!= e.Ref)      
 fprintf(fa,"%s %s %s %s %s \n",e.Ref,e.designation,e.marque,e.etat,e.date_achat);
}
fprintf(fa,"%s %s %s %s %s \n",e1.Ref,e1.designation,e1.marque,e1.etat,e1.date_achat);
fclose(f);
fclose(fa);
remove("equipement.txt");
rename("equipement1.txt","equipement.txt");
}
*/




void supprimer_equipement(equipement e) 
{
equipement e2;
    FILE *f=NULL;
    FILE *ftmp=NULL;
    f=fopen("equipement.txt","r");
    ftmp=fopen("equip_temp.txt","a+");
    if (f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat)!=EOF)
        {
            if (strcmp(e.Ref,e2.Ref)!=0)
                fprintf(ftmp,"%s %s %s %s %s \n",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat);
        }
    }
    fclose(f);
    fclose(ftmp);
    remove("equipement.txt");
    rename("equip_temp.txt","equipement.txt");
}





void chercher_equipement2(char ref[])
{ equipement e2;
    FILE *f=NULL;
    FILE *ftmp=NULL;
    f=fopen("equipement.txt","r");
    ftmp=fopen("cher.txt","w");
    if (f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat)!=EOF)
        {
            if (strcmp(e2.Ref,ref)==0)
                fprintf(ftmp,"%s %s %s %s %s \n",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat);
        }
    }
    fclose(f);
    fclose(ftmp);
}




void afficher_equipement(GtkWidget *liste)
{
enum
{
      REF=0,
      DESIGNATION,
      MARQUE,
      ETAT,
      DATE,
     COLUMNS
};
equipement e;
   
   GtkCellRenderer *renderer;
   GtkTreeIter iter;
   GtkListStore *store;
   GtkTreeViewColumn *column;
char Ref[30];
char designation[30];
char marque[30];
char etat[30];
char date_achat[30];
    FILE*f ;
   store=NULL;
   store=gtk_tree_view_get_model (liste);
   if (store==NULL)
   {  
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REF,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Designation",renderer,"text",DESIGNATION,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer,"text",MARQUE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Etat",renderer,"text",ETAT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Date_achat",renderer,"text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
 
f=fopen("equipement.txt","r");
   if (f==NULL)
   {
return;
   }
   else
   {
      while(fscanf(f,"%s %s %s %s %s\n",Ref,designation,marque,etat,date_achat)!=EOF)
     {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store,&iter,REF,Ref,DESIGNATION,designation,MARQUE,marque,ETAT,etat,DATE,date_achat,-1);
     }

    }
  fclose(f);
  gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
  g_object_unref (store);
    }

/////////////////////////////////////////////////////partie 2////////////////////////


void deffect()
{
equipement e2;
    FILE *f=NULL;
    FILE *ftmp=NULL;
    f=fopen("equipement.txt","r");
    ftmp=fopen("deff.txt","w");
    if (f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat)!=EOF)
        {
            if (strcmp(e2.etat,"EnPanne")==0)
                fprintf(ftmp,"%s %s %s %s %s \n",e2.Ref,e2.designation,e2.marque,e2.etat,e2.date_achat);
        }
    }
    fclose(f);
    fclose(ftmp);
     } 








void afficher_equipement2(GtkWidget *liste)
{
enum
{
      REFE,
      DESIGNATIONE,
      MARQUEE,
      ETATE,
      DATEE,
    COLUMNS,
};
equipement e;
   
   GtkCellRenderer *renderer;
   GtkTreeIter iter;
   GtkListStore *store;
   GtkTreeViewColumn *column;
char Ref[30];
char designation[30];
char marque[30];
char etat[30];
char date_achat[30];
    FILE*f ;
   store=NULL;
   store=gtk_tree_view_get_model (liste);
   if (store==NULL)
   {  
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Designation",renderer,"text",DESIGNATIONE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer,"text",MARQUEE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Etat",renderer,"text",ETATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Date_achat",renderer,"text",DATEE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
 
f=fopen("deff.txt","r");
   if (f==NULL)
   {
return;
   }
   else
   {
      while(fscanf(f,"%s %s %s %s %s\n",Ref,designation,marque,etat,date_achat)!=EOF)
     {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store,&iter,REFE,Ref,DESIGNATIONE,designation,MARQUEE,marque,ETATE,etat,DATEE,date_achat,-1);
     }

    }
  fclose(f);
  gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
  g_object_unref (store);
    }











void chercher_equipement(GtkWidget *liste)
{
enum
{
      REF=0,
      DESIGNATION,
      MARQUE,
      ETAT,
      DATE,
     COLUMNS
};
equipement e;
   
   GtkCellRenderer *renderer;
   GtkTreeIter iter;
   GtkListStore *store;
   GtkTreeViewColumn *column;
char Ref[30];
char designation[30];
char marque[30];
char etat[30];
char date_achat[30];
    FILE*f ;
   store=NULL;
   store=gtk_tree_view_get_model (liste);
   if (store==NULL)
   {  
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REF,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Designation",renderer,"text",DESIGNATION,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer,"text",MARQUE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Etat",renderer,"text",ETAT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Date_achat",renderer,"text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

 
   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
 
f=fopen("cher.txt","r");
   if (f==NULL)
   {
return;
   }
   else
   {
      while(fscanf(f,"%s %s %s %s %s\n",Ref,designation,marque,etat,date_achat)!=EOF)
     {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store,&iter,REF,Ref,DESIGNATION,designation,MARQUE,marque,ETAT,etat,DATE,date_achat,-1);
     }

    }
  fclose(f);
  gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
  g_object_unref (store);
    }



void marquedef22()
{

FILE *f=fopen("equipement.txt","r");
FILE *fc=fopen("marquedef.txt","a+");
equipement e;
if(f==NULL)
return;

else
{
while(fscanf(f,"%s %s %s %s %s\n",e.Ref,e.designation,e.marque,e.etat,e.date_achat)!=EOF)
if(strcmp(e.etat,"EnPanne")==0)
{
 fprintf(fc,"%s %s %s %s %s \n",e.Ref,e.designation,e.marque,e.etat,e.date_achat);
                  
}
}

 fclose(f);
 fclose(fc);

}










