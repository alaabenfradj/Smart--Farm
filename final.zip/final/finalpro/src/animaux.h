#ifndef ANIMAUX_H_
#define ANIMAUX_H_
#include<gtk/gtk.h>

typedef struct
{
  char matricule[20];
  char sexe[20];
   char jour[10];
   char mois[10];
  char annee[10];             
  char espece[20];
  char sante[20];
  char age[20];
  
}troupeaux;
typedef struct
{
char nbr[20];
char esp[20];
}nbtr;
              
//afficher
void afficher_troupeaux(GtkWidget *liste);
//ajouter
void ajouter(troupeaux a);
//supprimer
void supprimer(troupeaux s);


//modifier
void modifier(troupeaux m,troupeaux k);
//nombre de troupeaux de chaque type
void nb_troupeaux_type( );
void  aff_nbr(GtkWidget *liste);
int valider(char vd);
void chercher_crit(troupeaux p);
void afficher_rech(GtkWidget *liste);
void combobox(GtkWidget *combobox);
void rechmat(troupeaux p);
void supprimeraff(troupeaux s);
void modifierrech(troupeaux m,troupeaux k);


#endif 
