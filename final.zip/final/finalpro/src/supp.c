#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"

void supp(char n[20]) 
{
FILE *f, *f1;
plante p;
 
f1=NULL;
  f=fopen("planning_plante.txt","r");

  if (f==NULL)
{
return;
} 
     while (fscanf(f,"%s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte)!=EOF)
{
    if (strcmp(n,p.nom))

 
{  f1=fopen("planning_plante1.txt","a+");
  fprintf(f1," %s %s %s %s \n",p.nom,p.plantation,p.dosage,p.recolte);

fclose(f1);
}}
fclose(f);
 remove("planning_plante.txt"); rename("planning_plante1.txt","planning_plante.txt");
}
